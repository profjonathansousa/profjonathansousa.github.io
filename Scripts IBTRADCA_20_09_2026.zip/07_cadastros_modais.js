// =====================================================
// IBTRADCA — 07_cadastros_modais.js
// Versão 1.0
//
// Substitui os fluxos de cadastro por prompts sequenciais
// (ui.prompt) por modais HTML no sidebar, com dropdown para
// selecionar Aluno/Disciplina/Professor em vez de digitar código.
//
// 9 fluxos: Novo / Alterar / Ativar-Inativar × Aluno / Disciplina / Professor
//
// Cada fluxo expõe duas funções para o sidebar:
//   getListaXxx()              → popula o dropdown
//   _salvarXxx(dadosObjeto)     → grava a alteração
// =====================================================

var TURMAS_DISPONIVEIS = ["Curso Básico"];  // adicione novas turmas aqui


// =====================================================
// UTILITÁRIOS GENÉRICOS DE CADASTRO
// =====================================================

// Lê uma aba de cadastro inteira como array de objetos,
// usando o cabeçalho da linha 1 como chave de cada coluna.
function lerAbaComoObjetos_(nomeAba) {
  var aba = SpreadsheetApp.getActiveSpreadsheet().getSheetByName(nomeAba);
  if (!aba || aba.getLastRow() < 2) return [];
  var dados   = aba.getDataRange().getValues();
  var cabecalho = dados[0];
  var linhas  = dados.slice(1);

  return linhas
    .filter(function(l) { return l[0]; })
    .map(function(l, idx) {
      var obj = { _linha: idx + 2 };  // linha real na planilha (1-indexed + cabeçalho)
      cabecalho.forEach(function(campo, i) {
        obj[String(campo).trim()] = l[i];
      });
      return obj;
    });
}

function proximoCodigo_(lista, prefixo, largura) {
  var max = 0;
  lista.forEach(function(item) {
    var m = String(item.Codigo || "").match(new RegExp(prefixo + "(\\d+)"));
    if (m) { var n = parseInt(m[1]); if (n > max) max = n; }
  });
  return prefixo + String(max + 1).padStart(largura, "0");
}


// =====================================================
// ALUNOS
// Cadastro_Alunos: A=Codigo B=Nome C=Turma D=Situacao
// =====================================================

function getListaAlunosCompleta() {
  return lerAbaComoObjetos_("Cadastro_Alunos").map(function(a) {
    return { codigo: a.Codigo, nome: a.Nome, turma: a.Turma, situacao: a.Situacao, linha: a._linha };
  });
}

function getTurmasDisponiveis() {
  return TURMAS_DISPONIVEIS;
}

// dados = { nome, turma }
function _salvarNovoAluno(dados) {
  if (!dados || !dados.nome || !dados.nome.trim()) {
    return { ok: false, msg: "Nome é obrigatório." };
  }
  var aba   = SpreadsheetApp.getActiveSpreadsheet().getSheetByName("Cadastro_Alunos");
  var lista = getListaAlunosCompleta();
  var codigo = proximoCodigo_(lista.map(function(a){ return {Codigo:a.codigo}; }), "IBTR-", 3);

  var turma = (dados.turma && dados.turma.trim()) || TURMAS_DISPONIVEIS[0];

  aba.appendRow([codigo, dados.nome.trim().toUpperCase(), turma, "Ativo"]);
  atualizarFormulario();
  return { ok: true, msg: "Aluno cadastrado!\nCódigo: " + codigo };
}

// dados = { codigo, nome, turma }
function _salvarAlteracaoAluno(dados) {
  if (!dados || !dados.codigo) return { ok: false, msg: "Selecione um aluno." };
  var aba   = SpreadsheetApp.getActiveSpreadsheet().getSheetByName("Cadastro_Alunos");
  var lista = getListaAlunosCompleta();
  var item  = lista.find(function(a) { return a.codigo === dados.codigo; });
  if (!item) return { ok: false, msg: "Aluno não encontrado: " + dados.codigo };

  if (dados.nome && dados.nome.trim())   aba.getRange(item.linha, 2).setValue(dados.nome.trim().toUpperCase());
  if (dados.turma && dados.turma.trim()) aba.getRange(item.linha, 3).setValue(dados.turma.trim());

  return { ok: true, msg: "Aluno " + dados.codigo + " atualizado." };
}

// dados = { codigo }
function _alternarSituacaoAluno(dados) {
  if (!dados || !dados.codigo) return { ok: false, msg: "Selecione um aluno." };
  var aba   = SpreadsheetApp.getActiveSpreadsheet().getSheetByName("Cadastro_Alunos");
  var lista = getListaAlunosCompleta();
  var item  = lista.find(function(a) { return a.codigo === dados.codigo; });
  if (!item) return { ok: false, msg: "Aluno não encontrado: " + dados.codigo };

  var nova = item.situacao === "Ativo" ? "Inativo" : "Ativo";
  aba.getRange(item.linha, 4).setValue(nova);
  atualizarFormulario();
  return { ok: true, msg: dados.codigo + " — " + item.nome + " agora está " + nova + "." };
}


// =====================================================
// DISCIPLINAS
// Cadastro_Disciplinas: A=Codigo B=Nome C=Professor D=Turma E=CargaHoraria F=Situacao
// =====================================================

function getListaDisciplinasCompleta() {
  return lerAbaComoObjetos_("Cadastro_Disciplinas").map(function(d) {
    return {
      codigo: d.Codigo, nome: d.Nome, professor: d.Professor,
      turma: d.Turma, cargaHoraria: d.CargaHoraria, situacao: d.Situacao, linha: d._linha
    };
  });
}

// Lista de nomes de professores ativos, para popular o dropdown
// de "Professor" no cadastro de disciplina.
function getListaProfessoresParaDropdown() {
  return lerAbaComoObjetos_("Cadastro_Professores")
    .map(function(p) { return { codigo: p.Codigo, nome: p.Nome, situacao: p.Situacao }; })
    .sort(function(a, b) { return String(a.nome).localeCompare(String(b.nome), "pt"); });
}

// dados = { nome, professor, turma, cargaHoraria }
function _salvarNovaDisciplina(dados) {
  if (!dados || !dados.nome || !dados.nome.trim()) {
    return { ok: false, msg: "Nome da disciplina é obrigatório." };
  }
  var aba   = SpreadsheetApp.getActiveSpreadsheet().getSheetByName("Cadastro_Disciplinas");
  var lista = getListaDisciplinasCompleta();
  var codigo = proximoCodigo_(lista.map(function(d){ return {Codigo:d.codigo}; }), "IBTR-D", 2);

  var turma = (dados.turma && dados.turma.trim()) || TURMAS_DISPONIVEIS[0];
  var carga = dados.cargaHoraria ? Number(dados.cargaHoraria) : 8;

  aba.appendRow([codigo, dados.nome.trim(), dados.professor || "", turma, carga, "Inativo"]);
  atualizarFormulario();
  return { ok: true, msg: "Disciplina cadastrada!\nCódigo: " + codigo };
}

// dados = { codigo, nome, professor, turma }
function _salvarAlteracaoDisciplina(dados) {
  if (!dados || !dados.codigo) return { ok: false, msg: "Selecione uma disciplina." };
  var aba   = SpreadsheetApp.getActiveSpreadsheet().getSheetByName("Cadastro_Disciplinas");
  var lista = getListaDisciplinasCompleta();
  var item  = lista.find(function(d) { return d.codigo === dados.codigo; });
  if (!item) return { ok: false, msg: "Disciplina não encontrada: " + dados.codigo };

  if (dados.nome && dados.nome.trim())   aba.getRange(item.linha, 2).setValue(dados.nome.trim());
  if (dados.professor !== undefined)     aba.getRange(item.linha, 3).setValue(dados.professor || "");
  if (dados.turma && dados.turma.trim()) aba.getRange(item.linha, 4).setValue(dados.turma.trim());

  return { ok: true, msg: "Disciplina " + dados.codigo + " atualizada." };
}

// dados = { codigo }
function _alternarSituacaoDisciplina(dados) {
  if (!dados || !dados.codigo) return { ok: false, msg: "Selecione uma disciplina." };
  var aba   = SpreadsheetApp.getActiveSpreadsheet().getSheetByName("Cadastro_Disciplinas");
  var lista = getListaDisciplinasCompleta();
  var item  = lista.find(function(d) { return d.codigo === dados.codigo; });
  if (!item) return { ok: false, msg: "Disciplina não encontrada: " + dados.codigo };

  var nova = item.situacao === "Ativo" ? "Inativo" : "Ativo";

  // Aviso se for ativar mais de uma disciplina ao mesmo tempo
  if (nova === "Ativo") {
    var jaTemAtiva = lista.some(function(d) { return d.situacao === "Ativo" && d.codigo !== item.codigo; });
    if (jaTemAtiva) {
      return {
        ok: false,
        avisoConfirmacao: true,
        msg: "Já existe uma disciplina ativa. O sistema funciona melhor com apenas uma " +
             "disciplina ativa por vez. Deseja ativar mesmo assim?"
      };
    }
  }

  aba.getRange(item.linha, 6).setValue(nova);
  atualizarFormulario();
  return { ok: true, msg: item.codigo + " — " + item.nome + " agora está " + nova + "." };
}

// Confirmação forçada (usada quando o aviso de múltiplas disciplinas ativas foi aceito)
function _alternarSituacaoDisciplinaForcado(dados) {
  if (!dados || !dados.codigo) return { ok: false, msg: "Selecione uma disciplina." };
  var aba   = SpreadsheetApp.getActiveSpreadsheet().getSheetByName("Cadastro_Disciplinas");
  var lista = getListaDisciplinasCompleta();
  var item  = lista.find(function(d) { return d.codigo === dados.codigo; });
  if (!item) return { ok: false, msg: "Disciplina não encontrada: " + dados.codigo };

  var nova = item.situacao === "Ativo" ? "Inativo" : "Ativo";
  aba.getRange(item.linha, 6).setValue(nova);
  atualizarFormulario();
  return { ok: true, msg: item.codigo + " — " + item.nome + " agora está " + nova + "." };
}


// =====================================================
// PROFESSORES
// Cadastro_Professores: A=Codigo B=Nome C=Titulacao D=Disciplinas E=Contato F=Situacao
// =====================================================

function getListaProfessoresCompleta() {
  garantirAbaProfessores_();  // garante que a aba existe (definida em 03_arquivar_professores.js)
  return lerAbaComoObjetos_("Cadastro_Professores").map(function(p) {
    return {
      codigo: p.Codigo, nome: p.Nome, titulacao: p.Titulacao,
      disciplinas: p.Disciplinas, contato: p.Contato, situacao: p.Situacao, linha: p._linha
    };
  });
}

// dados = { nome, titulacao, disciplinas, contato }
function _salvarNovoProfessor(dados) {
  if (!dados || !dados.nome || !dados.nome.trim()) {
    return { ok: false, msg: "Nome é obrigatório." };
  }
  var aba   = garantirAbaProfessores_();
  var lista = getListaProfessoresCompleta();
  var codigo = proximoCodigo_(lista.map(function(p){ return {Codigo:p.codigo}; }), "IBTR-P", 2);

  aba.appendRow([
    codigo, dados.nome.trim().toUpperCase(),
    (dados.titulacao || "").trim(), (dados.disciplinas || "").trim(),
    (dados.contato || "").trim(), "Ativo"
  ]);
  return { ok: true, msg: "Professor cadastrado!\nCódigo: " + codigo };
}

// dados = { codigo, nome, titulacao, disciplinas, contato }
function _salvarAlteracaoProfessor(dados) {
  if (!dados || !dados.codigo) return { ok: false, msg: "Selecione um professor." };
  var aba   = garantirAbaProfessores_();
  var lista = getListaProfessoresCompleta();
  var item  = lista.find(function(p) { return p.codigo === dados.codigo; });
  if (!item) return { ok: false, msg: "Professor não encontrado: " + dados.codigo };

  if (dados.nome && dados.nome.trim())        aba.getRange(item.linha, 2).setValue(dados.nome.trim().toUpperCase());
  if (dados.titulacao !== undefined)          aba.getRange(item.linha, 3).setValue(dados.titulacao || "");
  if (dados.disciplinas !== undefined)        aba.getRange(item.linha, 4).setValue(dados.disciplinas || "");
  if (dados.contato !== undefined)            aba.getRange(item.linha, 5).setValue(dados.contato || "");

  return { ok: true, msg: "Professor " + dados.codigo + " atualizado." };
}

// dados = { codigo }
function _alternarSituacaoProfessor(dados) {
  if (!dados || !dados.codigo) return { ok: false, msg: "Selecione um professor." };
  var aba   = garantirAbaProfessores_();
  var lista = getListaProfessoresCompleta();
  var item  = lista.find(function(p) { return p.codigo === dados.codigo; });
  if (!item) return { ok: false, msg: "Professor não encontrado: " + dados.codigo };

  var nova = item.situacao === "Ativo" ? "Inativo" : "Ativo";
  aba.getRange(item.linha, 6).setValue(nova);
  return { ok: true, msg: item.codigo + " — " + item.nome + " agora está " + nova + "." };
}
// =====================================================
// IBTRADCA — 08_sincronizar_do_historico.js
// Versão 1.1
//
// PROBLEMA QUE RESOLVE:
// As abas Notas_Consolidadas, Frequencia_Consolidada e
// Resultado_Final só são alimentadas pelo fluxo normal do
// sistema (Form_Respostas_Notas/Presenca → Consolidar). Quando
// dados vêm de uma IMPORTAÇÃO direta para Historico_Consolidado,
// essas três abas ficam desatualizadas ou com lixo de testes
// anteriores — os PDFs por aluno (Notas, Frequência, Resultado)
// passam a mostrar informação errada, mesmo o Histórico estando
// correto.
//
// SOLUÇÃO:
// Sincroniza no sentido INVERSO do normal: lê o Historico_Consolidado
// (fonte de verdade) e REGRAVA do zero as três abas, garantindo que
// tudo bata com o que está no Histórico.
//
// Por padrão sincroniza TODOS os anos do Histórico. Para sincronizar
// só um ano específico, passe o ano como parâmetro:
//   sincronizarDoHistorico(2026)
//
// v1.1: adiciona removerRegistroHistorico() — remove um registro
//       equivocado do Histórico por aluno + disciplina (+ano) e
//       sincroniza os relatórios em seguida.
// =====================================================


// =====================================================
// FUNÇÃO PRINCIPAL
// anoFiltro: opcional. Se omitido, processa todos os anos.
// =====================================================
function sincronizarDoHistorico(anoFiltro) {
  var ui       = SpreadsheetApp.getUi();
  var planilha = SpreadsheetApp.getActiveSpreadsheet();
  var abaHist  = planilha.getSheetByName("Historico_Consolidado");

  var dados = abaHist.getDataRange().getValues();
  if (dados.length < 2) {
    ui.alert("Histórico vazio. Nada para sincronizar.");
    return;
  }

  var linhasHist = dados.slice(1).filter(function(l) {
    if (!l[1]) return false;
    if (anoFiltro && String(l[0]) !== String(anoFiltro)) return false;
    return true;
  });

  if (linhasHist.length === 0) {
    ui.alert("Nenhum registro encontrado" + (anoFiltro ? " para o ano " + anoFiltro : "") + ".");
    return;
  }

  var escopo = anoFiltro ? ("ano " + anoFiltro) : "TODOS os anos";
  var conf = ui.alert(
    "Sincronizar do Histórico",
    "Isso irá LIMPAR e REGRAVAR do zero as abas:\n\n" +
    "• Notas_Consolidadas\n• Frequencia_Consolidada\n• Resultado_Final\n\n" +
    "Escopo: " + escopo + " (" + linhasHist.length + " registro(s) no Histórico).\n\n" +
    "Qualquer dado que já estivesse nessas abas será substituído pelo " +
    "que está gravado no Histórico (fonte de verdade).\n\nConfirmar?",
    ui.ButtonSet.YES_NO
  );
  if (conf !== ui.Button.YES) return;

  _regravarNotasConsolidadas_(planilha, linhasHist);
  _regravarFrequenciaConsolidada_(planilha, linhasHist);
  _regravarResultadoFinal_(planilha, linhasHist);

  ui.alert(
    "Sincronização concluída!",
    "✔ " + linhasHist.length + " registro(s) do Histórico aplicado(s) a:\n" +
    "  • Notas_Consolidadas\n  • Frequencia_Consolidada\n  • Resultado_Final\n\n" +
    "Escopo: " + escopo,
    ui.ButtonSet.OK
  );
}


// =====================================================
// REGRAVA Notas_Consolidadas
// Layout: A=Aluno B=Disciplina C=Prova D=Trabalho E=Media F=Situacao
//
// O Histórico não distingue Prova de Trabalho (só tem Avaliação/Media
// final), então ambas as colunas recebem a mesma média — é a melhor
// aproximação possível sem perder informação na direção inversa.
// =====================================================
function _regravarNotasConsolidadas_(planilha, linhasHist) {
  var aba = planilha.getSheetByName("Notas_Consolidadas");
  aba.clearContents();
  aba.getRange(1, 1, 1, 6).setValues([[
    "Aluno", "Disciplina", "Prova", "Trabalho", "Media", "Situacao"
  ]]);

  var criterios = obterCriteriosAcademicos_();
  var linhas = linhasHist.map(function(l) {
    var aluno      = l[1];
    var disciplina = l[2];
    var media      = Number(l[4]) || 0;

    var situacao;
    if (media >= criterios.notaMinima) situacao = "APROVADO";
    else if (media > 0)                situacao = "PENDÊNCIA POR NOTA";
    else                                situacao = "PENDÊNCIA POR NOTA";

    return [aluno, disciplina, media, "", media, situacao];
  });

  // Ordena alfabeticamente por nome do aluno (independe da data de cadastro)
  linhas.sort(function(a, b) {
    return _chaveNomeAluno_(a[0]).localeCompare(_chaveNomeAluno_(b[0]), "pt");
  });

  if (linhas.length > 0) {
    aba.getRange(2, 1, linhas.length, 6).setValues(linhas);
  }

  aba.getRange(1, 1, 1, 6)
    .setBackground("#B40000").setFontColor("#FFFFFF").setFontWeight("bold");
  aba.autoResizeColumns(1, 6);
}


// =====================================================
// REGRAVA Frequencia_Consolidada
// Layout: A=Disciplina B=Aluno C=Presenças D=Faltas
//         E=Total F=Frequência% G=Situação
// =====================================================
function _regravarFrequenciaConsolidada_(planilha, linhasHist) {
  var aba = planilha.getSheetByName("Frequencia_Consolidada");
  aba.clearContents();
  aba.getRange(1, 1, 1, 7).setValues([[
    "Disciplina", "Aluno", "Presenças", "Faltas",
    "Total de Tempos", "Frequência %", "Situação"
  ]]);

  var criterios2 = obterCriteriosAcademicos_();
  var linhas = linhasHist.map(function(l) {
    var disciplina = l[2];
    var aluno      = l[1];
    var presencas  = Number(l[5]) || 0;
    var total      = Number(l[6]) || 0;
    var faltas     = Math.max(total - presencas, 0);
    var freqStr    = String(l[7] || "0%");
    var freqNum    = parseFloat(freqStr.replace("%", "").replace(",", ".")) || 0;

    var situacao = freqNum < criterios2.freqMinima ? "RISCO DE PENDÊNCIA" : "REGULAR";

    return [disciplina, aluno, presencas, faltas, total, freqStr, situacao];
  });

  // Ordena alfabeticamente por nome do aluno (coluna B, índice 1)
  linhas.sort(function(a, b) {
    return _chaveNomeAluno_(a[1]).localeCompare(_chaveNomeAluno_(b[1]), "pt");
  });

  if (linhas.length > 0) {
    aba.getRange(2, 1, linhas.length, 7).setValues(linhas);

    // Força coluna F (Frequência%) como texto puro
    aba.getRange(2, 6, linhas.length, 1).setNumberFormat("@");

    for (var r = 0; r < linhas.length; r++) {
      var cor = linhas[r][6] === "RISCO DE PENDÊNCIA" ? "#FCE4D6" : "#E2EFDA";
      aba.getRange(2 + r, 7).setBackground(cor);
    }
  }

  aba.getRange(1, 1, 1, 7)
    .setBackground("#B40000").setFontColor("#FFFFFF").setFontWeight("bold");
  aba.autoResizeColumns(1, 7);
}


// =====================================================
// REGRAVA Resultado_Final
// Layout: A=Aluno B=Disciplina C=Media D=Frequencia E=Situacao F=Observacao
// =====================================================
function _regravarResultadoFinal_(planilha, linhasHist) {
  var aba = planilha.getSheetByName("Resultado_Final");
  aba.clearContents();
  aba.getRange(1, 1, 1, 6).setValues([[
    "Aluno", "Disciplina", "Media", "Frequencia", "Situacao", "Observacao"
  ]]);

  var linhas = linhasHist.map(function(l) {
    var aluno      = l[1];
    var disciplina = l[2];
    var media      = Number(l[4]) || 0;
    var freqStr    = String(l[7] || "0%");
    var situacao   = l[8] || "";

    return [aluno, disciplina, media, freqStr, situacao, ""];
  });

  // Ordena alfabeticamente por nome do aluno (coluna A, índice 0)
  linhas.sort(function(a, b) {
    return _chaveNomeAluno_(a[0]).localeCompare(_chaveNomeAluno_(b[0]), "pt");
  });

  if (linhas.length > 0) {
    aba.getRange(2, 1, linhas.length, 6).setValues(linhas);

    // Força coluna D (Frequencia) como texto puro
    aba.getRange(2, 4, linhas.length, 1).setNumberFormat("@");

    for (var r = 0; r < linhas.length; r++) {
      var cor = "#FFFFFF";
      var s   = linhas[r][4];
      if (s === "APROVADO")                       cor = "#E2EFDA";
      if (s === "PENDÊNCIA POR NOTA")             cor = "#FFF2CC";
      if (s === "PENDÊNCIA POR FALTA")            cor = "#FCE4D6";
      if (s === "PENDÊNCIA POR NOTA E PRESENÇA")  cor = "#FCE4D6";
      aba.getRange(2 + r, 5).setBackground(cor);
    }
  }

  aba.getRange(1, 1, 1, 6)
    .setBackground("#B40000").setFontColor("#FFFFFF").setFontWeight("bold");
  aba.autoResizeColumns(1, 6);
}


// =====================================================
// Chave de ordenação alfabética a partir de "IBTR-004 — NOME".
// Remove o código de matrícula para ordenar pelo NOME real do aluno,
// não pela matrícula. Assim um aluno cadastrado hoje aparece na
// posição alfabética correta, e não no fim da lista.
// =====================================================
function _chaveNomeAluno_(alunoCompleto) {
  var s = String(alunoCompleto || "");
  // remove "IBTR-NNN" e o separador (— / - ) do começo
  s = s.replace(/^\s*IBTR-\d+\s*[—\-]*\s*/i, "");
  return s
    .replace(/–|—|―/g, "-")
    .replace(/\.\s*$/, "")
    .replace(/\s+/g, " ")
    .trim()
    .toUpperCase();
}


// =====================================================
// REMOVER REGISTRO DO HISTÓRICO (por aluno + disciplina)
//
// Ferramenta genérica e reutilizável para apagar do
// Historico_Consolidado um registro equivocado — por exemplo,
// uma disciplina que o aluno ainda nem cursou, gravada por engano
// na fase de teste/implementação do sistema.
//
// Fluxo (chamado pelo menu IBTRADCA → Manutenção do Histórico):
//   1) Pergunta a matrícula do aluno (ex: IBTR-004)
//   2) Mostra TODAS as disciplinas que o aluno tem no Histórico
//      e pergunta o CÓDIGO da disciplina a remover (ex: IBTR-D19)
//   3) (Opcional) restringe a um ano específico
//   4) Confirma exibindo exatamente qual linha será apagada
//   5) Remove a linha do Historico_Consolidado
//   6) Roda sincronizarDoHistorico() automaticamente, para que o
//      registro suma também de Notas/Frequência/Resultado e dos PDFs
//
// Como localiza a linha: cruza matrícula (extraída da coluna B,
// tolera "IBTR-004—NOME" ou "IBTR-004 — NOME") com o código da
// disciplina (extraído da coluna C, tolera com ou sem código).
// NÃO depende da disciplina estar ativa — funciona para qualquer
// disciplina do histórico, ativa ou não.
// =====================================================

// Extrai o código IBTR-DNN de um texto de disciplina.
// Aceita "IBTR-D19 — Ética Cristã", "IBTR-D19—Ética", "IBTR-D19".
function _extrairCodigoDisciplina_(texto) {
  if (!texto) return "";
  var m = String(texto).toUpperCase().match(/IBTR-D\d+/);
  return m ? m[0].trim() : "";
}

function removerRegistroHistorico() {
  var ui       = SpreadsheetApp.getUi();
  var planilha = SpreadsheetApp.getActiveSpreadsheet();
  var abaHist  = planilha.getSheetByName("Historico_Consolidado");

  if (!abaHist || abaHist.getLastRow() < 2) {
    ui.alert("Histórico vazio. Nada para remover.");
    return;
  }

  // 1) Matrícula do aluno
  var rMat = ui.prompt(
    "Remover registro do Histórico (1/2)",
    "Digite a MATRÍCULA do aluno (ex: IBTR-004):",
    ui.ButtonSet.OK_CANCEL
  );
  if (rMat.getSelectedButton() !== ui.Button.OK) return;
  var matricula = extrairMatricula_(rMat.getResponseText());
  if (!matricula) {
    ui.alert("Matrícula inválida. Use o formato IBTR-004.");
    return;
  }

  var dados = abaHist.getDataRange().getValues();

  // Coleta os registros desse aluno (para mostrar e validar a escolha)
  // Layout: A=Ano B=Aluno C=Disciplina D=Avaliacao E=Media F=Presencas G=Total H=Freq% I=Situacao
  var registrosAluno = [];  // { linhaPlanilha, ano, disciplina, codigo, situacao }
  for (var i = 1; i < dados.length; i++) {
    if (extrairMatricula_(String(dados[i][1])) === matricula) {
      registrosAluno.push({
        linhaPlanilha: i + 1,
        ano:           String(dados[i][0]),
        disciplina:    String(dados[i][2]),
        codigo:        _extrairCodigoDisciplina_(dados[i][2]),
        situacao:      String(dados[i][8])
      });
    }
  }

  if (registrosAluno.length === 0) {
    ui.alert("Nenhum registro encontrado no Histórico para " + matricula + ".");
    return;
  }

  // Lista as disciplinas do aluno para orientar a escolha
  var lista = registrosAluno.map(function(r) {
    return "  • " + (r.codigo || "(sem código)") + "  —  " + r.ano + "  —  " + r.disciplina;
  }).join("\n");

  // 2) Código da disciplina a remover
  var rCod = ui.prompt(
    "Remover registro do Histórico (2/2)",
    "Aluno: " + matricula + "\n\nDisciplinas no histórico deste aluno:\n\n" + lista +
    "\n\nDigite o CÓDIGO da disciplina a remover (ex: IBTR-D19):",
    ui.ButtonSet.OK_CANCEL
  );
  if (rCod.getSelectedButton() !== ui.Button.OK) return;
  var codigoAlvo = _extrairCodigoDisciplina_(rCod.getResponseText());
  if (!codigoAlvo) {
    ui.alert("Código inválido. Use o formato IBTR-D19.");
    return;
  }

  // Filtra os registros que batem com a disciplina escolhida
  var alvos = registrosAluno.filter(function(r) { return r.codigo === codigoAlvo; });

  if (alvos.length === 0) {
    ui.alert("O aluno " + matricula + " não possui a disciplina " + codigoAlvo + " no histórico.");
    return;
  }

  // Se houver mais de um ano com a mesma disciplina, pergunta o ano
  if (alvos.length > 1) {
    var anos = alvos.map(function(r) { return r.ano; }).join(", ");
    var rAno = ui.prompt(
      "Vários registros encontrados",
      "Existem " + alvos.length + " registros de " + codigoAlvo + " para este aluno, nos anos: " + anos +
      "\n\nDigite o ANO do registro que deseja remover:",
      ui.ButtonSet.OK_CANCEL
    );
    if (rAno.getSelectedButton() !== ui.Button.OK) return;
    var anoAlvo = String(rAno.getResponseText()).trim();
    alvos = alvos.filter(function(r) { return r.ano === anoAlvo; });
    if (alvos.length === 0) {
      ui.alert("Nenhum registro de " + codigoAlvo + " no ano " + anoAlvo + " para " + matricula + ".");
      return;
    }
  }

  // 3) Confirmação final mostrando exatamente o que será removido
  var resumo = alvos.map(function(r) {
    return "• " + r.ano + " — " + r.disciplina + " (" + r.situacao + ")";
  }).join("\n");

  var conf = ui.alert(
    "Confirmar remoção",
    "Será REMOVIDO do Histórico o(s) seguinte(s) registro(s) de " + matricula + ":\n\n" +
    resumo + "\n\n" +
    "Em seguida, os relatórios (Notas, Frequência, Resultado) serão sincronizados " +
    "automaticamente a partir do Histórico corrigido.\n\n" +
    "Esta ação não pode ser desfeita. Confirmar?",
    ui.ButtonSet.YES_NO
  );
  if (conf !== ui.Button.YES) return;

  // Remove as linhas de baixo para cima (para não deslocar os índices)
  var linhasParaRemover = alvos.map(function(r) { return r.linhaPlanilha; })
                               .sort(function(a, b) { return b - a; });
  linhasParaRemover.forEach(function(linha) {
    abaHist.deleteRow(linha);
  });

  // 4) Sincroniza automaticamente para propagar a correção aos relatórios.
  //    sincronizarDoHistorico() já tem seu próprio diálogo de confirmação.
  ui.alert(
    "Registro removido",
    linhasParaRemover.length + " linha(s) removida(s) do Histórico para " + matricula + " — " + codigoAlvo + ".\n\n" +
    "Agora será executada a sincronização dos relatórios. Confirme na próxima tela.",
    ui.ButtonSet.OK
  );
  sincronizarDoHistorico();
}


// =====================================================
// COMO USAR:
// No editor do Apps Script, selecione a função
// "sincronizarDoHistorico" no seletor de função e clique em
// Executar. Um diálogo de confirmação vai aparecer na planilha.
//
// Para sincronizar todos os anos (padrão):
//   sincronizarDoHistorico()
//
// Para sincronizar só um ano específico, edite a chamada ou
// crie uma função auxiliar própria, ex:
//   function sincronizar2026() { sincronizarDoHistorico(2026); }
//
// Para remover um registro equivocado do Histórico:
//   Menu IBTRADCA → Manutenção do Histórico → "Remover Registro do Histórico"
//   (função removerRegistroHistorico)
// =====================================================

// =====================================================
// IBTRADCA — sidebar_ibtradca.js
// Painel lateral com todos os controles do sistema
// =====================================================

// =====================================================
// ABRE O PAINEL LATERAL
// Chamado pelo onOpen() automaticamente
// =====================================================
function abrirPainel() {
  var html = HtmlService.createHtmlOutputFromFile("sidebar_ibtradca_html")
    .setTitle("IBTRADCA")
    .setWidth(280);
  SpreadsheetApp.getUi().showSidebar(html);
}

// =====================================================
// onOpen: abre o painel e cria o menu ao carregar
// =====================================================
function old_onOpen() {
  abrirPainel();
  SpreadsheetApp.getUi()
    .createMenu("IBTRADCA")
    .addItem("Abrir painel de controle", "abrirPainel")
    .addSeparator()
    .addSubMenu(
      SpreadsheetApp.getUi().createMenu("Presença")
        .addItem("Fechar Aula", "fecharAula")
        .addItem("Atualizar Formulário", "atualizarFormulario")
        .addItem("Consolidar Frequência", "consolidarFrequencia")
    )
    .addSubMenu(
      SpreadsheetApp.getUi().createMenu("Notas")
        .addItem("Consolidar Notas", "consolidarNotas")
        .addItem("Resultado Final", "gerarResultadoFinal")
        .addItem("Arquivar Disciplina", "arquivarDisciplina")
    )
    .addSubMenu(
      SpreadsheetApp.getUi().createMenu("Relatórios PDF")
        .addItem("PDF — Alunos", "gerarPDFAlunos")
        .addItem("PDF — Disciplinas", "gerarPDFDisciplinas")
        .addItem("PDF — Frequência", "gerarPDFFrequencia")
        .addItem("PDF — Notas", "gerarPDFNotas")
        .addItem("PDF — Resultado Final", "gerarPDFResultado")
        .addItem("PDF — Histórico por Aluno", "gerarPDFHistoricoAluno")
    )
    .addSubMenu(
      SpreadsheetApp.getUi().createMenu("Consultas")
        .addItem("Histórico do Aluno", "consultarHistoricoAluno")
    )
    .addToUi();
}

// =====================================================
// WRAPPERS — chamados pelo painel via google.script.run
// Retornam string para o callback de sucesso/erro
// =====================================================

function _fecharAula()           { fecharAula();           return "ok"; }
function _atualizarFormulario()  { atualizarFormulario();  return "ok"; }
function _consolidarFrequencia() { consolidarFrequencia(); return "ok"; }
function _consolidarNotas()      { consolidarNotas();      return "ok"; }
function _gerarResultadoFinal()  { gerarResultadoFinal();  return "ok"; }
function _arquivarDisciplina()   { arquivarDisciplina();   return "ok"; }
function _gerarPDFAlunos()       { gerarPDFAlunos();       return "ok"; }
function _gerarPDFDisciplinas()  { gerarPDFDisciplinas();  return "ok"; }
function _gerarPDFFrequencia()   { gerarPDFFrequencia();   return "ok"; }
function _gerarPDFNotas()        { gerarPDFNotas();        return "ok"; }
function _gerarPDFResultado()    { gerarPDFResultado();    return "ok"; }
function _gerarPDFHistoricoAluno(){ gerarPDFHistoricoAluno(); return "ok"; }

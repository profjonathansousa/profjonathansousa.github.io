// =====================================================
// IBTRADCA — 02_notas_resultado.js
// Versão 5.1
//
// CORRIGE:
//  - Cruzamento nota×frequência por MATRÍCULA (IBTR-NNN),
//    não mais pela string completa do nome.
//    Resolve: notas lançadas não apareciam no Resultado_Final
//    porque o nome vinha "IBTR-001—NOME" vs "IBTR-001 — NOME".
//  - Aluno SEM frequência consolidada agora aparece no Resultado
//    com frequência 0% e observação clara (antes sumia ou era
//    classificado errado).
//
//  v5.1:
//  - Notas_Consolidadas e Resultado_Final gravados em ordem
//    alfabética por nome do aluno (independe da data de cadastro).
// =====================================================


// Chave de ordenação alfabética por NOME a partir de "IBTR-001 — NOME".
// Remove a matrícula para ordenar pelo nome real, não pelo código.
function _chaveNomeAlunoNotas_(alunoCompleto) {
  var s = String(alunoCompleto || "");
  s = s.replace(/^\s*IBTR-\d+\s*[—\-]*\s*/i, "");
  return normalizar_(s);
}


// =====================================================
// CONSOLIDAR NOTAS
// Form_Respostas_Notas (sem cabeçalho de dados):
//   A=Timestamp B=Disciplina C=Tipo D=Aluno E=Nota
// =====================================================
function consolidarNotas() {
  const planilha   = SpreadsheetApp.getActiveSpreadsheet();
  const abaOrigem  = planilha.getSheetByName("Form_Respostas_Notas");
  const abaDestino = planilha.getSheetByName("Notas_Consolidadas");

  abaDestino.clearContents();
  abaDestino.getRange(1, 1, 1, 6).setValues([[
    "Aluno", "Disciplina", "Prova", "Trabalho", "Media", "Situacao"
  ]]);

  const dados = abaOrigem.getDataRange().getValues();
  // ATENÇÃO: a 1ª linha PODE ser cabeçalho ("Data",...). Detecta e pula.
  let inicio = 0;
  if (dados.length > 0 && String(dados[0][0]).toLowerCase().indexOf("data") === 0) {
    inicio = 1;
  }

  let consolidado = {};
  for (let r = inicio; r < dados.length; r++) {
    const linha         = dados[r];
    const disciplina    = linha[1];
    const tipo          = linha[2];
    const alunoCompleto = String(linha[3]);
    const nota          = Number(linha[4]);

    if (!alunoCompleto || alunoCompleto.indexOf("IBTR") === -1) continue;

    // chave por matrícula + disciplina normalizada
    const matricula = extrairMatricula_(alunoCompleto);
    const chave     = matricula + "|" + normalizar_(disciplina);

    if (!consolidado[chave]) {
      consolidado[chave] = {
        aluno:      alunoCompleto,   // texto como veio
        disciplina: disciplina,
        prova:      "",
        trabalho:   ""
      };
    }

    const tipoNorm = (tipo == "Avaliação Final") ? "Prova" : tipo;
    if (tipoNorm == "Prova")    consolidado[chave].prova    = nota;
    if (tipoNorm == "Trabalho") consolidado[chave].trabalho = nota;
  }

  var criterios = obterCriteriosAcademicos_();
  let linhas = [];
  for (let chave in consolidado) {
    const item     = consolidado[chave];
    const prova    = Number(item.prova    || 0);
    const trabalho = Number(item.trabalho || 0);

    let media = 0, contador = 0;
    if (prova    > 0) { media += prova;    contador++; }
    if (trabalho > 0) { media += trabalho; contador++; }
    media = contador > 0 ? media / contador : 0;

    const situacao = media >= criterios.notaMinima ? "APROVADO" : "PENDÊNCIA POR NOTA";

    linhas.push([
      item.aluno, item.disciplina, item.prova, item.trabalho, media, situacao
    ]);
  }

  // Ordena alfabeticamente por nome do aluno (coluna A, índice 0)
  linhas.sort(function(a, b) {
    return _chaveNomeAlunoNotas_(a[0]).localeCompare(_chaveNomeAlunoNotas_(b[0]), "pt");
  });

  if (linhas.length > 0) {
    abaDestino.getRange(2, 1, linhas.length, 6).setValues(linhas);
  }

  abaDestino.getRange(1, 1, 1, 6)
    .setBackground("#B40000").setFontColor("#FFFFFF").setFontWeight("bold");
  abaDestino.autoResizeColumns(1, 6);

  SpreadsheetApp.getUi().alert("Notas consolidadas com sucesso.");
}


// =====================================================
// RESULTADO FINAL
// Notas_Consolidadas:      A=Aluno B=Disc C=Prova D=Trab E=Media F=Sit
// Frequencia_Consolidada:  A=Disc B=Aluno C=Pres D=Faltas E=Total F=Freq% G=Sit
// Cruza por MATRÍCULA.
// =====================================================
function gerarResultadoFinal() {
  const planilha      = SpreadsheetApp.getActiveSpreadsheet();
  const abaNotas      = planilha.getSheetByName("Notas_Consolidadas");
  const abaFrequencia = planilha.getSheetByName("Frequencia_Consolidada");
  const abaResultado  = planilha.getSheetByName("Resultado_Final");

  abaResultado.clearContents();
  abaResultado.getRange(1, 1, 1, 6).setValues([[
    "Aluno", "Disciplina", "Media", "Frequencia", "Situacao", "Observacao"
  ]]);

  const dadosNotas      = abaNotas.getDataRange().getValues();
  const dadosFrequencia = abaFrequencia.getDataRange().getValues();
  dadosNotas.shift();
  dadosFrequencia.shift();

  // Mapa de frequência por matrícula + disciplina
  let mapaFreq = {};
  dadosFrequencia.forEach(function(linha) {
    const disciplina = linha[0];
    const aluno      = linha[1];
    const freq       = linha[5];
    if (!aluno) return;
    const chave = extrairMatricula_(aluno) + "|" + normalizar_(disciplina);
    mapaFreq[chave] = freq;
  });

  let linhas = [];
  var criterios2 = obterCriteriosAcademicos_();
  dadosNotas.forEach(function(linha) {
    const alunoCompleto = String(linha[0]);
    const disciplina    = linha[1];
    const media         = Number(linha[4]);
    if (!alunoCompleto || alunoCompleto.indexOf("IBTR") === -1) return;

    const chave = extrairMatricula_(alunoCompleto) + "|" + normalizar_(disciplina);

    let freqRaw    = mapaFreq[chave];
    let temFreq    = (freqRaw !== undefined && freqRaw !== null && freqRaw !== "");
    let frequencia = 0;
    if (temFreq) {
      frequencia = (typeof freqRaw === "string")
        ? Number(freqRaw.replace("%", "").replace(",", "."))
        : Number(freqRaw);
    }

    let situacao, observacao = "";
    var temNota = (media > 0);
    if (!temFreq && !temNota) {
      situacao   = "PENDÊNCIA POR NOTA E PRESENÇA";
      observacao = "Sem nota e sem frequência";
    } else if (!temFreq) {
      // Tem nota mas sem frequência consolidada → pendência por falta
      situacao   = "PENDÊNCIA POR FALTA";
      observacao = "Frequência não consolidada";
    } else if (frequencia < criterios2.freqMinima && !temNota) {
      situacao = "PENDÊNCIA POR NOTA E PRESENÇA";
    } else if (frequencia < criterios2.freqMinima) {
      situacao = "PENDÊNCIA POR FALTA";
    } else if (media >= criterios2.notaMinima) {
      situacao = "APROVADO";
    } else {
      situacao = "PENDÊNCIA POR NOTA";
    }

    linhas.push([
      alunoCompleto, disciplina, media,
      (temFreq ? frequencia + "%" : "—"), situacao, observacao
    ]);
  });

  // Ordena alfabeticamente por nome do aluno (coluna A, índice 0)
  linhas.sort(function(a, b) {
    return _chaveNomeAlunoNotas_(a[0]).localeCompare(_chaveNomeAlunoNotas_(b[0]), "pt");
  });

  if (linhas.length > 0) {
    abaResultado.getRange(2, 1, linhas.length, 6).setValues(linhas);
    for (var r = 0; r < linhas.length; r++) {
      var cor = "#FFFFFF";
      var s = linhas[r][4];
      if (s === "APROVADO")                        cor = "#E2EFDA";
      if (s === "PENDÊNCIA POR NOTA")              cor = "#FFF2CC";
      if (s === "PENDÊNCIA POR FALTA")             cor = "#FCE4D6";
      if (s === "PENDÊNCIA POR NOTA E PRESENÇA")   cor = "#FCE4D6";
      abaResultado.getRange(2 + r, 5).setBackground(cor);
    }
  }

  abaResultado.getRange(1, 1, 1, 6)
    .setBackground("#B40000").setFontColor("#FFFFFF").setFontWeight("bold");
  abaResultado.autoResizeColumns(1, 6);

  SpreadsheetApp.getUi().alert("Resultado final atualizado com sucesso.");
}


// =====================================================
// FINALIZAR LANÇAMENTO (Portal do Professor → Controle)
// Mantido, com detecção de cabeçalho na origem.
// =====================================================
function finalizarLancamento() {
  const ID_PRINCIPAL = "1_FdSVuQeMSVdtL4xOxPqTyZwvrAdSE2gWiOPN_jHEyg";
  const planilhaProf = SpreadsheetApp.getActiveSpreadsheet();
  const abaLanc      = planilhaProf.getSheetByName("Lancamento_Notas");
  const abaDestino   = SpreadsheetApp.openById(ID_PRINCIPAL)
                          .getSheetByName("Form_Respostas_Notas");

  const disciplina = abaLanc.getRange("B1").getValue();
  const tipo       = abaLanc.getRange("B2").getValue();
  const data       = abaLanc.getRange("B3").getValue();
  const ult        = abaLanc.getLastRow();

  const dados = abaLanc.getRange(6, 1, ult - 5, 2).getValues();

  let envio = [];
  dados.forEach(function(linha) {
    const aluno = linha[0];
    const nota  = linha[1];
    if (aluno === "" || nota === "" || nota === null) return;
    envio.push([new Date(), disciplina, tipo, data, aluno, nota]);
  });

  if (envio.length == 0) { SpreadsheetApp.getUi().alert("Nenhuma nota preenchida."); return; }

  abaDestino.getRange(abaDestino.getLastRow() + 1, 1, envio.length, 6).setValues(envio);
  abaLanc.getRange(6, 2, ult - 5, 1).clearContent();

  SpreadsheetApp.getUi().alert("Lançamento enviado com sucesso.");
}


// =====================================================
// LANÇAR NOTA MANUAL (via sidebar)
// Insere diretamente em Form_Respostas_Notas e dispara consolidação.
// dados = { aluno: string, disciplina: string, tipo: string, nota: number }
// =====================================================
function _lancarNotaManual(dados) {
  try {
    if (!dados || !dados.aluno || !dados.disciplina || !dados.tipo || dados.nota === "" || dados.nota === null || dados.nota === undefined) {
      return { ok: false, msg: "Preencha todos os campos antes de lançar." };
    }

    var nota = Number(dados.nota);
    if (isNaN(nota) || nota < 0 || nota > 10) {
      return { ok: false, msg: "Nota inválida. Use um valor entre 0 e 10." };
    }

    var planilha = SpreadsheetApp.getActiveSpreadsheet();
    var aba      = planilha.getSheetByName("Form_Respostas_Notas");
    if (!aba) return { ok: false, msg: "Aba Form_Respostas_Notas não encontrada." };

    aba.appendRow([new Date(), dados.disciplina, dados.tipo, dados.aluno, nota]);

    // Reconsolida automaticamente
    consolidarNotas();

    return { ok: true, msg: "Nota lançada e notas reconsolidadas com sucesso." };
  } catch(e) {
    return { ok: false, msg: "Erro: " + e.message };
  }
}

// Lista de disciplinas para dropdown de nota manual (todas, ativas e inativas)
function getListaDisciplinasParaNota() {
  return getListaDisciplinasCompleta()
    .sort(function(a, b) { return String(a.codigo).localeCompare(String(b.codigo), "pt"); })
    .map(function(d) {
      return {
        codigo: d.codigo,
        nome: d.nome,
        situacao: d.situacao,
        completo: d.codigo + " — " + d.nome
      };
    });
}

// =====================================================
// WRAPPERS
// =====================================================
function _consolidarNotas()     { consolidarNotas();     return "ok"; }
function _gerarResultadoFinal()  { gerarResultadoFinal(); return "ok"; }

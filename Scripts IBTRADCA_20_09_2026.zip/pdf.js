// =====================================================
// IBTRADCA — 04_pdf.js
// Versão 5.1
//
// ADICIONA / CORRIGE:
//  - PDF de Alunos: opção de imprimir Ativos, Inativos ou Todos
//  - Ordenação SEMPRE alfabética (por nome) em todos os PDFs por aluno
//  - v5.1: PDF de Disciplinas ordenado por CÓDIGO (IBTR-D01, D02, ...)
//          com ordenação numérica correta (D2 antes de D10)
//  - v5.1: PDF de Histórico por aluno ordenado por código de disciplina
// =====================================================


// Logo do IBTR em base64, embutida para uso nos cabeçalhos dos relatórios PDF.
// Gerada a partir do arquivo de logo fornecido; fundo removido (transparente).
var LOGO_IBTR_BASE64 = "iVBORw0KGgoAAAANSUhEUgAAAFMAAABGCAYAAACwqagoAAAbj0lEQVR4nO18eXgUVbr+e05V752ks5CFYAIJWYgRJIBAWBJEQFmGNSiKP3B0ZBnm3mFGLjpzr91hUYRHRUEFnGEYVIRuEQREgUgS2QYloGASCMSQQCBkX7vT3VX13T+6G4OC4Iwk3N/4Pk8e6qk6dfr73vq289UpgP874ETEO1qI//MQRBEQBADAxYKC4IulpeNEtRoA2C8E3yKIiBERy/rLX9af2rjxYyIaCCL20Ysvlh177/1XIApXx3WwqACAO/qp5lgsAmOMgrX6b0teXzM6e/acLAKGB7hce8vXr59//pOsNUTkD5uN3ymE3rEgq1UAACK679MxY93rAPr41082FH24tfyvasH1yYiRVHrk6BwAyM7OFjtWWqDDBfhR5OeT96jKIahh0Gmpbsd2/7xDh/0N/sF0JXe/G6tCXqbW1lKm1e4mq1VgU6fKHSXuHe3muPtur+u6u+hdDi5IEnQyEb90kTjJTO9n4rWf7tHlLn1xORHpkJ9PHenud7ZldurECGA1x76O96+u4nBLEhwOUeIEuVWCotIKisMuNe7bd3f5qBEzumRmrsn26CR1hLh3NJk5OTkYBlDBseN9UFICIwcUlwsggpszyG4FOkHkzV8dp8Kttj8Q0TtgzE5EjDFGN/+Fnxd3rJuT1SoMy8yUiCjBcfL4466mGuL+giDqFYgaQCMS9LITWncrN7a2knA0L67l/Pk0xhjBZusQve5IyyQiBsaIiNjZ999e58y2GvXBTFYYBCYDJBMgA8zNwCQZogJFKSpi52xb00G0Oyc/v0Pi5h1JJvLWiYwxd83Zk//VZFszVGOvk1mAIAgSAQoDyYAsERS3h1AuglFdLWstO59ORHoLY60d4ep3nJvTsWMq1neWmxTl0Zqtb74kfXNcUoWpBKZVwA0AMwAwELiBIBgIXA/AwDhnEqimOhaAXyagAGh367yjLJOys0XWt6+biBJLN7z4auO2vyj6CJGDFIgaBigAKQQmAXADighwDpDE4NYDLc3VOlzVydLu8t8xZFJ2tsiGDZOIKOxy1ru2xu2rQrV+iiyomEBEAHxksqtkMicgcwa4wEgEGQJ0WgBRAMqBu/89LdPj2n3dRNSl6ujWT6o3Pp8sOC/LYqAgKEwBZ/AQKRFIhodMF8A5AzhB4RxQg9QGLQdg9Mya0e56dDiZVmuG4CUy5fKeNbYrm1+I0dRfkMUQUSCmQBAYAAZSAKYAkAByA8QJxDwWyzggqMG4VkMA6jtKlw4l02q1ClOnTpWJXAtK3n1+UdOHK7VaapLVwaKgcBmMi1fTCANAJEOQCSTgKpEgBgWkqIzgPCi4CsA33iWl0t76dBiZRCQwxmQi6bdXNi1dXv23xQgMhOL2VwsKV8C5CmAcxBgIDCAFnHEAMqBSQICHLgUgSSYxUAMhJOAogEjG2LmOWKN3SGlERNxDJA0u2bh0ddlqs+Tvz0nSClzNZE8sZCIYF8EFDQRRAy6owQQVIKhAKg6oGKACFDXABQhN2gCKHPbQ/cW5uw8SUThjjIjM7apfu5NJRBwWC4gorHTHGlvlX18k/wCRK2owgQOMA8Q5GFeBC2pw7iNVDcZUYIx7LJQDTGQQRQ6lFdAl92aiwUTlry4Jqz7w6ZtEJLR3ddQBlmljLDNTqTp+aHnje2+FG52tsqQCZ0SempExMGJgDJ4ikjEA5PmXeZLR1WPGwEkht0pA5ylPVNV/k2d3HzlCl7I/HQEggGVmKu3p7u1KJlmtAmNTZSLqdcW2boor/6QMgygwxdsx8y7+GPMcEtE1f4CXZOC79Q0pjGkIzcXfmC5vfC3IxJiCEyeMLRUXJgIAcnKE9tKvfS3TZgMRac/vsv6P/PlevUrNQJLCSGFQCJCJoJACGQAUGVC8iQYMDB5CZXgSEhFApEAiQAVCw5tLVMLpPEFtIFLOncaVowdGAoDtzTfbbX3ebtn8atIB4us//2x8S2kF+UeIApNkcBIAt6yQoCgCByMOrjCFQXaBEwMHB5gKzG1XyNlKkgxABuAEmCQKkAhaAXBBgUtgTK6pRUvhmW5ExMFYu5VI7Vca5eRwAMqVr44OkY8fFTWMSZKbiaLIINVIsiZEFNQhIZzBBVdLLSBCFnRqQZEZOOdw2BsVITCc63r0BOkCQNWVcH17Dk1nykkjAK0KZ0zigALuapZAlTVxAEwMqG2vDlK7kWl7800CY6j74svhSsl5CBxAq4QGF1HYpCmCtvfgAiE4+BjnUgS/cranu/CzMGfRUdngpxaaWhyy/t4HhcCRvz3hlzh4sSiaHJK9Ut945vjjlP3RhPot6yE43cRcnDE3A5dlyNU1QAd0jtoNRCTkPbug8LCB0fFIUc6NViln1y0hotb/JiKVZxQHEYU6a4u2nV/1CH01Gs6yl4aTq+Gc9bsx18w568zK5xxHYrl8vBtXjnYWlAMi6MgjUxuIKMw75v8fUn3KEFHw4aeerD0ogI7oIJ+YM10mojm+cdnmNNGaAd+7cuYoO7b5q7m95drs9WeIKNp7XkVkFYhI+MacoQaA5oqzf/pqwn10JBDSF53USi5An09/rI6IOrX9/duN2+bmN4hTzF7byNUyAJORBw4f9QVj7C0ym0VYLDJjTAK87TjGJCJ6JuiRPz/cwAzPBTFW6j3vbvMbRHfbBIR13+iOiH9ebv1CI6pAbgCGiM4MP3xL6S1abw9uR2nE0tLSxBsEfIkx0SUBEIO6QNe1+wkym3lOOtB2vLevyQBWbkhMHdN18IM7iYizYcO+Tw55Nx3YuTHQzlyA5JBkQa2DOjDoHwCazABnV4tTUEZGhnC7LPVnJTMjI0MAQLm5uRIRabOzs7XANUQ1IiS4zg2AJA6XQ6qwAEhH+g/mYowRY6Dg0M67GWNudv0Sx0eKn6u6RifJIKebSLmrC3SxMXsYY9K4p9cKAOjw4cM6IlLZbDaZMUZeWX9W/CxkegVjNptN1uv1WLBgwdxXX311t6IokfBs+2PWjAyBC4Kijo3a7w4Oo8bKCjQWFXW3WCwMOTk3rAWJrDdW2mZjBDD75dLZrOCcVgLkepDoSIiTe0ydug8AmqbFk9VqFbRabbcVK1bsWbBgwWwi4jabTQbAzeafrxnyL03kdRfBZrPJfn5+tGLFikeGDBmS39DQ8HSPHj2eGT58eLHZbGZeSwApCno99th7Uu97WUVdLdUc+2ISgLssuHGSYOzGe4dy8vMZY5yKP/hoQEvBN3BrtIo70ATjff3+AaDADPBhw4ZJ+fn5lJKSUhASEvKf1dXVv54yZcrZV155ZarBYFAyMzMVALfN9W8KImJpaWkiAOj1ehw6dGh4enr6/tTUVHr66afXeJPPNQQRwMhjpdrPFy8+/Y7BqHzQPZa+eX/T38E4yGwW28S2m8vw3Q65fntGj3FuE9Xy+1qt++MHRlLLhfP/0XaMT2YA0Gg0eOKJJ9b06dOHRo0alXPo0KFUlcpTcaWlpYntSmrbWENEd02fPv2txMRE6tOnj+v111+f5BXM2965FlavcrUXS8dtGzGSNgDu7SNH0pXTpx4HgGyz+ZaqCyLi5owMNRFFHnnhhePWoBD6IMDk3BLemQ6uWPEJEXEym3+wZ9Pr0lwURbz00ku/6tmzpyM+Pp6efPLJdUTU5Xo63hZ4BRO9x+ply5Y9k5ycXB0aGkrjxo3LIqIE79AffbpWq1WAIODw6tWbt0RF0981WufOh6c5Gy9cmAwAa59+WvVj9xORzyJDC7ba9m3uHkfWQJP7bzqtsm/uvDoiivNev1EIa6tHzPjx44+EhYVRr169qhcvXvxbIvI90NtjpT6LYowhKytrxLhx444GBQVRfHw8LViwYIGfnx8Aj5vcbC6z2czNns3+ATl/eq5sU1AQbdRpXbsfnkZXTnw90zeurYt+Xw4iii6wbsmy3n0P2Yw6599ErXvn9MeppfrKPO/1m+YCs9cLiEjz7LPPmmNiYshkMtHYsWOPfvLJJ+m+kHNbrJSITL/5zW9ejouLI845DR48+FRWVtYIzjnwE7+E8I0losH7f7/g8kZTIP1NEJ3W9OFUvOvjDURkAICMNonh2Nq1Ku89cd+8897Xm+K60yYVd23wD6LP//AMOaoqZnuu/0j2/x68bs8459i6deuDgwcPLmSMUVxcHP3+979/g4iCbpmgW1CaEZF22bJljw4YMKBIr9eTRqORnn322Wwi8v/ecMFqtd5yVmyTQHofyFxSvC3pHloPyLaEBDqybFkeEQ2EymPo5ceO6b1jux7JzCx8NzSM3ha4Yu2dQl++urKYiJ7kooDrxckb6eW1cuF75wP//Oc/H1Gr1ZJer6ehQ4cWL1u2bBIRqf8ll/e5VG5u7oxJkya1BgUFkV6vJ845de7c2ZmcnPzFzJkzX9q6desAIjJ4LdQH8VbqtzaEBhdusC766JHpLdbu3WmDfwB9+OBDdNpq/ZCIwgHg/MGD07dNn9Hy98gutKlPPzpgttRePPyPBURk8k53U2W9Ml0NRd6KQ7V9+/ahs2fPfv2ee+75MjIy0sUYI61WS2FhYTR58uTmTz/9dCwAdjOdbipAdna2mJ6e7vfGG2/Enz17tkdBQcGKS5cuKXV1daFutxsqlQpRUVE13bp12/TII4/s/NWvfnWAMdbquz8jI0OwWq3KjfqJZrOZe2s9ENG9JZ/t/03VwUMDLuYdi9ZGRgYjObmkz5ixti+2WB+Ti4oa4tOHnDH16722c2JyAWPsgvc+gTF23XqUiFh6erqQm5srtTmn3rFjx/3vvvvug0VFRZOrqqq6SJIEtVqNoKCgmvDwcOrRo8cfBw4ceH7MmDFnjEZj5c/eD33qqaf+NHfu3DwiMu7evbv3okWLnhs2bNjmmJiYy9HR0RQfH0/9+vW7OG3atBdycnLuCQgIaHu7cL0n6/WAa84TkUBE0UQ05FTOoX4XTp/uSUR+2mvnAwA8fYPs7/2tq27s7++PgwcP3jtt2rQVycnJJTExMdS1a1eKiYm5PGTIkHcyMzOfyc3NTSEi05w5c/Lmz59v+eeZugHS0tJEQRDwxz/+cenIkSNp165dQ9teFwQBROT3/vvvj5w5c+argwYNKuvevTslJibSiBEjChYuXDiHiMLahIEfkKrT6bB69eqp8+bO/cC6adMIkd/Ym3RaLQ4dOjRh6dKlS2pra6N8532EerMvbyNb6Pz58+elp6ef6tGjByUkJNDAgQNLpkyZsnTjxo33E5FeEK7NWRs3bkxNS0ujhQsXPi+K4i1VKTdFRkaGwBjDypUr5ycmJtK8efNe1ul0gCfuiN27d9cA0MAbLjjnICJxz549fZ544okXevfuXdi7d28aOHCgMm3atL9mZWUlqT2f6QGeTK3atGnTiNGjR2+LiooilUpF3bt3p2nTpr1ns9n6U0mJ1mq1Cr747XA4Yuf8ds665ORkCggIoJSUlLp58+Y92yYZcsCzytm9e3fSxIkT30pNTaWUlBRKTU09+9RTT72QnZ19r69W9YIB0Hp1EX1zPProo0t69OhBL7/88pOAxwP+JSIBYPv27VMSEhLogQceKCSiMCIK8PPzg1arxc2Wf96sOXjy5MmvDxo0qLlv3740fvz4/W+88UaaWq3Gzp07f52enk7wvtmFp/9IAGjs2LH2zz///EGvsmzDhg3/b+jQoW3HugCQSqWicePGlZ0+fbqfRqPBa6+9NmzMmDH7UlJS6L777qt7+OGHV+/Zs+f+m2Vjxhh0Oh2ISENEgUQUkZ6eXpCQkEC7d+8e15aTG85xvZO+DVVWq3Xi4sWLPzx16pRiMpkUURRbgoKCFLVafdHPz682KCioLCQk5FzPnj3PDxo0qKh///7fGo3GSqfTCUm6tvVIRKYFCxZMOHPmzMKGhoZEtVqdM3HixFe6detWsX379lUHDx5MOH/+vF9sbGxj//79D/Tv319xu91L5s6de9xqtfKamprw/fv3j2tubv7PY8eOdauqqtJ069atuV+/fidSU1MlnU635aOPPprZ1NQ0wGg0fh0bG7t01apVuxljLW3lUKlU0Ol0aGhoCDl06FCPvLy8hLy8vNArV67EOByO7m63O7qurs5UWVnJABhqa2vFXr16wWw2T5g0adJHbRPmLZHpi2kOh2NEeXn58+Xl5fc5HI7S6urqoJaWloDW1lauKAoURQFjDGq1GgaDAd469FTnzp3PJCYmnuzUqdOe55577lt/f/+apqamq8qsXLkybe/evX9obGwcc/fdd39WWlqaAIAlJSW58/Pz/TnnxWPGjJHz8vL+tG7dus/Xrl2rmjVrlpuIQqZPn/6FSqXSqNXqy3V1dYFdu3atc7lckYWFheGCIHw4ceLElbNmzTrg2bTgSTwNDQ1By5cvjykpKUm7fPnygPLy8p719fVxTqeTORwOuFwuAICieDjS6XRuk8nUYjQaK3Q6Xdfg4ODPRo8e/cHs2bM3erP6dTP7dcn0vXIgItWCBQtODBgwYM38+fNXl5WV+QMIAqA9evSoac+ePYGiKCYVFxdHlJaWdm5paYmura3t4nA4ugiCwIkIWq0WISEh54OCgrJSUlKOTJkyJbdXr17FjDHs3bs3Ojs7+7Vt27aNz8/Ph06nI4fDweLj4+u3bNny7MmTJz+ZMWNGmdlsFi0Wi7xz586+c+bM+aK8vBzh4eHOiooKTVpaGh588MHcCRMmzOrRo8cZvV6PgwcPxm3ZsqVfUVHRyNra2vuvXLlyl9vthqIokGWZBEEoDQoK+jYoKKgqMjKyLCoqqiQwMPByr169Lg8bNqwRQDOA+i5dujS9+OKL/3H06NGpq1evHuqtS+lGZdJ1yfTWhppp06btOHTo0HCtVptjt9sDQkJCTHa73a7RaOjSpUvnBUFoiI+PV/R6fWW3bt2a+vTp44yMjLwYHBxsdzqdQkFBQURWVpahoqIixeVy9WOMRSuKQlqt9nRoaOjeiIiIDdu2bftqwIABOdu2bRvKGHMTkXrIkCG5X375ZXpra+vVh2uxWJjFYolITEz8+syZM8HwbEMQJk+evPbAgQOzZ82aNbCwsPCxhoaGCQ0NDZHeMFNiMBiOhYeHf/3AAw80xcfHV6rV6qb6+vrQc+fOBRYUFPiXlZUF1dbWBhQXFwtGo7Gz0Wjs5HK5OBGJkiS59Hp9c2Nj44DU1NTdmzdvnmCxWORbdnNfTCgvL49avnz5+uPHjwtEdE9DQwPV1dWRVqvt1NTUBJfLBY1GA0VR4Ha7IUkSBEGASqWCKIoQRVExGo2lYWFhZ2NjY0tjY2NLo6OjXWVlZa1FRUWx1dXV9zU2NkZpNJra8ePH1+/atWvQgQMHlCFDhiAjI2Oz0Wh8curUqS6r1Srk5+dTpmcTlnrlypV733rrrQEXL14Uhw0b1jJq1KjsDz74IJZz7hcQEFARERHxZUxMTElgYGBzSUlJwLlz56LKyspi6+vrE5qbm6NcLpfIOYfT6YSiKBBFEYIggDEGu90OrVYLk8kEt9tdFxgYKDkcjsrAwMBLqamp2kWLFj1iMBgu3Shu/miG45xDo9HAbrf7+pMcQGhRURHbt2+faDAYugDoWllZqSkpKUFNTQ20Wm1kVVVVcHl5uVGn0yVUVlaG+Pn5xTDG1IqiQKVS2XU63am77rrrdFJS0nlZlgceOHBgZEVFhXLhwgUeFRXl7t27t2rEiBGHAMyYOXNmMQCsX78+Ljg4+N39+/cnZmVlCRUVFYbk5OS6hIQETVxc3Lra2tq64uLi6Jqamr5VVVXdXC6Xn1qthizLEmOswt/f/7zb7T4fHBxcGx0d3dzQ0FAcERFBsbGxLCAgwFVfX1/c0tJyYdSoUXTvvfcCQA0Al8FgUGRZBuccdrv9R3eG/FjfkLHvap+fvF+Hc371qdvtdl1jY2OXzZs3dz59+nTvs2fPxra0tPTW6/XxZWVlplOnTn1/FaSMGzcOo0eP3tXa2vqsKIoiY2zpjh07xu7du/f7MtP06dPrXS6Xq6qq6oLb7d4XFhZWMGjQoJLHH3+8OiQkpMzf39/hdDohyzJk+Sd/Qe0zpBsmnrYDbwrfawgAMJvNV+8pKChgSUlJDPB8NOpDbm7u1VvheRA/EEKlUmHJkiWzFy1a9JbD4ZB8TVlv4Q+j0di6atWqvX5+fi6VSqWUlpZGzZs3rw/nXITn9Qc45yTLMsLDw9m+ffsG9evX77Avzl4Hgk/ftLS0qyfT09N9ulBSUtJVOS0WCwHXvoK+GW5pmdR2wszMzJ+84PclkIKCAgYAlZWVqtzcXPfx48eNkiRJiuLZoMk5Z/AQRVqtViPLcoPBYPiHRqNBQ0PDwyqVSpQkib6blgiAJMsy37ZtW3hrayufMWOG2m63uwEgKSmJLBaLL/teNck2D/ua47bIzMz8qWq2z8at79dmaWlpDIDcrVs3ITQ0VKysrBR9pYsPTqdTBuCSZdmPcx6iKEqzLMuydyXD4bVOAIKfnx86d+4sAFC6du0qZWZmXiXunyHln0WHfG2Rk5MjM8bYQw89tCkkJKTu+PHjgRcvXoxzuVxxiqJ0ra6uNoWEhPjrdDpraGhodp8+fVS7du16OioqarTT6URgYKBTrVbXBAQEXBBF8VR0dHRR165dDwOAt3TpCLXurC13Go0Gra2tupMnTwYXFhYmqtXqE5MmTaoDoKxcuTLZ5XKlBAYGnp4yZUqlyWSqMhqNLXa7Hb7Vzr81vC7LfO+tAfygeSKKItpevw6Edn/ffQN02EdVVqtVYIzJO3bsGLlq1ar/SUpKKm1ubtbm5+cHd+rUSejSpcvHoaGhcnZ29mN2u72Ocx4wYMAAdunSpebLly+rO3XqJMTFxb29fPnyty0WS4f8NxLfR4d9b56RkaEAYOPGjTtRXl6eUllZmVNVVeWUJCk4JSVlzddff72MiCJiYmKO1NfX9wgPDy8JDg4+6XQ6U0wm07GQkJD3Tpw4sRZAaGY7f6JyI3QYmT5LEgShSpKkipKSkrMGg+GsJEmds7KynomIiLicmZm5aMOGDXP1er0SEBDw8tKlS2e6XK7S6urqgYWFhWMjIiJ2AKg3m83839oyffCuiwWj0SgTkdZoNF44ePDgY1euXIlYuHDhDABgjKldLpdGkiSIoqiNjIwsDQwMDHC5XG5RFJ2++rWj0ZFuLgCgt99++z4AnaKiop5qamoaVFVVFTVp0qSVfn5+9f369cuxWCyz7Ha7v0qletzhcPSur6/vQkTSwIEDswsKCiavXr16ps1mk2/7/qBbQIclIJvNpgDA0aNHz5pMpr4qlYrp9XrY7XYmSZLpnXfeOR8SElL+u9/9rkWj0fSqqalR8vLyqhVF6eVt6kput/svJ0+edLSd7xfcGHeE+94q7gRhGTy7JQB4ln9tjhVf98psNsNisZDFYrkqc2Zm5o92vn/BL/gFv+Bnxv8CZFXmFCOkaKsAAAAASUVORK5CYII=";

function limparNome_(texto) {
  if (!texto) return "";
  return texto.toString()
    .replace(/–|—|―/g, "-")
    .replace(/\.\s*$/, "")
    .replace(/\s+/g, " ")
    .trim();
}

function _lerAba_(nomeAba) {
  var planilha = SpreadsheetApp.getActiveSpreadsheet();
  var aba = planilha.getSheetByName(nomeAba);
  if (!aba) return [];
  var oculta = aba.isSheetHidden();
  if (oculta) aba.showSheet();
  var dados = aba.getDataRange().getValues();
  if (oculta) aba.hideSheet();
  dados.shift();
  return dados;
}

// ordena array de linhas por uma coluna de nome, locale pt
function ordenarPorNome_(arr, idxNome) {
  return arr.sort(function(a, b) {
    return limparNome_(String(a[idxNome])).localeCompare(limparNome_(String(b[idxNome])), "pt");
  });
}

// ordena array de linhas por CÓDIGO de disciplina (IBTR-DNN),
// com ordenação NUMÉRICA correta: IBTR-D01, D02, ..., D09, D10, D11...
// (uma ordenação textual simples colocaria D10 antes de D2).
// idxCodigo = índice da coluna que contém o código (ou "IBTR-DNN — Nome").
function ordenarPorCodigoDisciplina_(arr, idxCodigo) {
  function numDe(v) {
    var m = String(v || "").toUpperCase().match(/IBTR-D(\d+)/);
    return m ? parseInt(m[1], 10) : 999999;   // sem código vai para o fim
  }
  return arr.sort(function(a, b) {
    var na = numDe(a[idxCodigo]), nb = numDe(b[idxCodigo]);
    if (na !== nb) return na - nb;
    // desempate: texto do código/nome
    return String(a[idxCodigo]).localeCompare(String(b[idxCodigo]), "pt");
  });
}


// =====================================================
// PDF — ALUNOS com filtro (Ativos / Inativos / Todos)
// filtro: "ativos" | "inativos" | "todos"
// =====================================================
function gerarPDFTodosAlunos(filtro) {
  filtro = filtro || "todos";
  var planilha  = SpreadsheetApp.getActiveSpreadsheet();
  var abaAlunos = planilha.getSheetByName("Cadastro_Alunos");

  var oculta = abaAlunos.isSheetHidden();
  if (oculta) abaAlunos.showSheet();
  var dados = abaAlunos.getDataRange().getValues();
  if (oculta) abaAlunos.hideSheet();
  dados.shift();

  var ativos   = ordenarPorNome_(dados.filter(function(r){ return String(r[3]).trim() === "Ativo"; }), 1);
  var inativos = ordenarPorNome_(dados.filter(function(r){ return String(r[3]).trim() !== "Ativo"; }), 1);

  function bloco(arr, titulo, cor, corSit, txtSit) {
    if (arr.length === 0) return "";
    var html = '<tr><td colspan="4" style="background:'+cor+';color:#fff;font-weight:bold;padding:6px 8px;font-size:11px;">'
             + titulo + ' (' + arr.length + ')</td></tr>';
    arr.forEach(function(r, idx) {
      var bg = idx % 2 === 0 ? "#FFFFFF" : "#F1F3F4";
      html += '<tr style="background:'+bg+'"><td>'+r[0]+'</td><td>'+r[1]+'</td><td>'+r[2]+'</td>'
            + '<td style="color:'+corSit+';font-weight:bold">'+txtSit+'</td></tr>';
    });
    return html;
  }

  var linhas = "";
  var subtitulo = "";
  if (filtro === "ativos") {
    linhas = bloco(ativos, "Ativos", "#B40000", "#1E5C0A", "Ativo");
    subtitulo = "Somente alunos ativos";
  } else if (filtro === "inativos") {
    linhas = bloco(inativos, "Inativos", "#80868B", "#888", "Inativo");
    subtitulo = "Somente alunos inativos";
  } else {
    linhas = bloco(ativos, "Ativos", "#B40000", "#1E5C0A", "Ativo")
           + bloco(inativos, "Inativos", "#80868B", "#888", "Inativo");
    subtitulo = "Todos os alunos cadastrados";
  }

  var totalMostrado = (filtro === "ativos") ? ativos.length
                    : (filtro === "inativos") ? inativos.length
                    : dados.length;

  var resumo = '<div class="resumo"><strong>Exibidos:</strong> '+totalMostrado
             + ' &nbsp;|&nbsp; <strong>Ativos:</strong> '+ativos.length
             + ' &nbsp;|&nbsp; <strong>Inativos:</strong> '+inativos.length+'</div>';

  var tabela = '<table><thead><tr><th>Código</th><th>Nome</th><th>Turma</th><th>Situação</th>'
             + '</tr></thead><tbody>' + linhas + '</tbody></table>' + resumo;

  _abrirRelatorioHTML_("Cadastro de Alunos", subtitulo, tabela);
}

// Wrappers para o sidebar (um por filtro)
function _gerarPDFAlunosAtivos()   { gerarPDFTodosAlunos("ativos");   return "ok"; }
function _gerarPDFAlunosInativos() { gerarPDFTodosAlunos("inativos"); return "ok"; }
function _gerarPDFAlunosTodos()    { gerarPDFTodosAlunos("todos");    return "ok"; }
// compat menu
function gerarPDFAlunos() { gerarPDFTodosAlunos("todos"); }


// =====================================================
// PDF — DISCIPLINAS (ordenado por CÓDIGO: IBTR-D01, D02, ...)
// =====================================================
function gerarPDFTodasDisciplinas() {
  var planilha = SpreadsheetApp.getActiveSpreadsheet();
  var abaDisc  = planilha.getSheetByName("Cadastro_Disciplinas");

  var oculta = abaDisc.isSheetHidden();
  if (oculta) abaDisc.showSheet();
  var dados = abaDisc.getDataRange().getValues();
  if (oculta) abaDisc.hideSheet();
  dados.shift();

  // Ordena por código de disciplina (coluna A, índice 0), numericamente.
  var ativas   = ordenarPorCodigoDisciplina_(dados.filter(function(r){ return String(r[5]).trim() === "Ativo"; }), 0);
  var inativas = ordenarPorCodigoDisciplina_(dados.filter(function(r){ return String(r[5]).trim() !== "Ativo"; }), 0);

  function bloco(arr, titulo, cor, corSit, txtSit) {
    if (arr.length === 0) return "";
    var html = '<tr><td colspan="5" style="background:'+cor+';color:#fff;font-weight:bold;padding:6px 8px;font-size:11px;">'
             + titulo + ' (' + arr.length + ')</td></tr>';
    arr.forEach(function(r, idx) {
      var bg = idx % 2 === 0 ? "#FFFFFF" : "#F1F3F4";
      html += '<tr style="background:'+bg+'"><td>'+r[0]+'</td><td>'+r[1]+'</td><td>'+(r[2]||"—")+'</td>'
            + '<td>'+r[3]+'</td><td style="color:'+corSit+';font-weight:bold">'+txtSit+'</td></tr>';
    });
    return html;
  }

  var linhas = bloco(ativas,"Ativas","#B40000","#1E5C0A","Ativo")
             + bloco(inativas,"Inativas","#80868B","#888","Inativo");
  var resumo = '<div class="resumo"><strong>Total:</strong> '+dados.length
             + ' &nbsp;|&nbsp; <strong>Ativas:</strong> '+ativas.length
             + ' &nbsp;|&nbsp; <strong>Inativas:</strong> '+inativas.length+'</div>';
  var tabela = '<table><thead><tr><th>Código</th><th>Disciplina</th><th>Professor</th>'
             + '<th>Turma</th><th>Situação</th></tr></thead><tbody>'+linhas+'</tbody></table>'+resumo;

  _abrirRelatorioHTML_("Cadastro de Disciplinas", "Todas as disciplinas cadastradas (ordem por código)", tabela);
}
function _gerarPDFDisciplinas() { gerarPDFTodasDisciplinas(); return "ok"; }
function gerarPDFDisciplinas()  { gerarPDFTodasDisciplinas(); }


// =====================================================
// LISTA DE ALUNOS (para selects do sidebar) — ordenada por NOME
// =====================================================
function getListaAlunos() {
  var aba = SpreadsheetApp.getActiveSpreadsheet().getSheetByName("Cadastro_Alunos");
  if (!aba || aba.getLastRow() < 2) return [];
  var dados = aba.getRange(2, 1, aba.getLastRow()-1, 4).getValues();
  var lista = [];
  dados.forEach(function(l) {
    var codigo = String(l[0]).trim();
    var nome   = String(l[1]).trim().replace(/\.\s*$/, "");
    if (codigo) lista.push({ codigo: codigo, nome: nome, situacao: String(l[3]).trim(),
                             completo: codigo + " — " + nome });
  });
  lista.sort(function(a,b){ return a.nome.localeCompare(b.nome, "pt"); });
  return lista;
}


// =====================================================
// RELATÓRIO HTML genérico (modal imprimível)
// =====================================================
function _abrirRelatorioHTML_(titulo, subtitulo, conteudo) {
  var data = Utilities.formatDate(new Date(), Session.getScriptTimeZone(), "dd/MM/yyyy");
  var html =
    '<!DOCTYPE html><html><head><meta charset="UTF-8"><style>' +
    'body{font-family:Arial;margin:0;padding:20px;color:#222;}' +
    'h1{color:#B40000;font-size:15px;margin:0;}h2{color:#B40000;font-size:12px;margin:3px 0 0;}' +
    '.hdr{border-bottom:2px solid #B40000;padding-bottom:10px;margin-bottom:12px;display:flex;align-items:center;gap:12px;}' +
    '.hdr-logo{height:48px;width:auto;flex-shrink:0;}' +
    '.hdr-texto{flex:1;}' +
    '.info{font-size:12px;margin-bottom:12px;line-height:1.6;}' +
    '.vazio{font-size:12px;color:#888;padding:16px;background:#f5f5f5;border-radius:6px;text-align:center;margin-top:8px;}' +
    'table{width:100%;border-collapse:collapse;font-size:11px;}' +
    'th{background:#B40000;color:#fff;padding:6px;text-align:left;border:1px solid #ddd;}' +
    'td{padding:5px 6px;border:1px solid #ddd;}' +
    '.resumo{margin-top:12px;font-size:11px;padding:7px;background:#f5f5f5;border-radius:4px;}' +
    '.rodape{margin-top:16px;font-size:10px;color:#888;border-top:1px solid #ddd;padding-top:6px;}' +
    '.np{margin-top:14px;}@media print{.np{display:none;}}' +
    '#btn-imprimir[disabled]{opacity:0.6;cursor:wait;}' +
    '</style></head><body>' +
    '<div class="hdr">' +
      '<img class="hdr-logo" src="data:image/png;base64,' + LOGO_IBTR_BASE64 + '" alt="Logo IBTR">' +
      '<div class="hdr-texto"><h1>Instituto Bíblico Teológico Rhema — IBTRADCA</h1><h2>'+titulo+'</h2></div>' +
    '</div>' +
    '<div class="info"><strong>'+subtitulo+'</strong><br><strong>Data de emissão:</strong> '+data+'</div>' +
    conteudo +
    '<div class="rodape">Emitido em '+data+' — Instituto Bíblico Teológico Rhema (IBTRADCA) | Desenvolvido por Jonathan Sousa</div>' +
    '<div class="np"><button id="btn-imprimir" onclick="imprimirComSeguranca()" style="margin-top:12px;padding:10px 22px;background:#B40000;color:#fff;border:none;border-radius:6px;font-size:13px;cursor:pointer;">🖨 Imprimir / Salvar como PDF</button></div>' +
    '<script>' +
    // O Chrome às vezes captura um frame em branco para o "Salvar como PDF"
    // se window.print() é chamado antes do layout terminar de ser pintado
    // (comum em conteúdo carregado dinamicamente, como este modal).
    // Forçar dois requestAnimationFrame + um pequeno timeout garante que
    // o navegador já completou pelo menos um ciclo de pintura antes de imprimir.
    'function imprimirComSeguranca(){' +
      'var btn=document.getElementById("btn-imprimir");' +
      'btn.disabled=true;btn.textContent="Preparando...";' +
      'requestAnimationFrame(function(){' +
        'requestAnimationFrame(function(){' +
          'setTimeout(function(){' +
            'window.print();' +
            'btn.disabled=false;btn.textContent="🖨 Imprimir / Salvar como PDF";' +
          '},150);' +
        '});' +
      '});' +
    '}' +
    '</script>' +
    '</body></html>';
  SpreadsheetApp.getUi().showModalDialog(
    HtmlService.createHtmlOutput(html).setWidth(820).setHeight(600), titulo);
}


// =====================================================
// PDFs POR ALUNO (frequência / notas / resultado / histórico)
// Cruzam por matrícula. Dentro de cada aluno, ordena por disciplina
// (código) para leitura consistente.
// =====================================================
function gerarPDFFrequenciaAluno(alunoCompleto) {
  var dados = _lerAba_("Frequencia_Consolidada");
  var mat = extrairMatricula_(alunoCompleto);
  var regs = dados.filter(function(r){ return extrairMatricula_(r[1]) === mat; });
  // Frequencia_Consolidada: A=Disciplina(0) B=Aluno(1) ... — ordena por código da disciplina
  ordenarPorCodigoDisciplina_(regs, 0);

  var conteudo;
  if (regs.length === 0) {
    conteudo = '<div class="vazio">Nenhum registro de frequência. Execute "Consolidar frequência".</div>';
  } else {
    var linhas = "";
    regs.forEach(function(r) {
      var sit = String(r[6]);
      var cor = sit === "RISCO DE PENDÊNCIA" ? "#FCE4D6" : "#E2EFDA";
      var abonadas = Number(r[7]) || 0;
      var celAbonadas = abonadas > 0
        ? '<td style="text-align:center;color:#8B0000;font-weight:bold">' + abonadas + '</td>'
        : '<td style="text-align:center;color:#9AA0A6">0</td>';
      linhas += '<tr style="background:'+cor+'"><td>'+r[0]+'</td>'
              + '<td style="text-align:center">'+r[2]+'</td><td style="text-align:center">'+r[3]+'</td>'
              + '<td style="text-align:center">'+r[4]+'</td><td style="text-align:center">'+r[5]+'</td>'
              + celAbonadas
              + '<td style="font-weight:bold">'+sit+'</td></tr>';
    });
    conteudo = '<table><thead><tr><th>Disciplina</th><th style="text-align:center">Presenças</th>'
             + '<th style="text-align:center">Faltas</th><th style="text-align:center">Tempos Registrados</th>'
             + '<th style="text-align:center">Freq%</th><th style="text-align:center">Faltas Abonadas</th>'
             + '<th>Situação</th></tr></thead><tbody>'
             + linhas + '</tbody></table>';
  }
  _abrirRelatorioHTML_("Frequência — " + alunoCompleto, alunoCompleto, conteudo);
}

function gerarPDFNotasAluno(alunoCompleto) {
  var dados = _lerAba_("Notas_Consolidadas");
  var mat = extrairMatricula_(alunoCompleto);
  var regs = dados.filter(function(r){ return extrairMatricula_(r[0]) === mat; });
  // Notas_Consolidadas: A=Aluno(0) B=Disciplina(1) ... — ordena por código da disciplina
  ordenarPorCodigoDisciplina_(regs, 1);

  var conteudo;
  if (regs.length === 0) {
    conteudo = '<div class="vazio">Nenhuma nota encontrada. Execute "Consolidar notas".</div>';
  } else {
    var linhas = "";
    regs.forEach(function(r) {
      var sit = String(r[5]);
      var cor = sit === "APROVADO" ? "#E2EFDA" : "#FFF2CC";
      linhas += '<tr style="background:'+cor+'"><td>'+r[1]+'</td>'
              + '<td style="text-align:center">'+r[2]+'</td><td style="text-align:center">'+r[3]+'</td>'
              + '<td style="text-align:center">'+r[4]+'</td><td style="font-weight:bold">'+sit+'</td></tr>';
    });
    conteudo = '<table><thead><tr><th>Disciplina</th><th style="text-align:center">Prova</th>'
             + '<th style="text-align:center">Trabalho</th><th style="text-align:center">Média</th>'
             + '<th>Situação</th></tr></thead><tbody>'+linhas+'</tbody></table>';
  }
  _abrirRelatorioHTML_("Notas — " + alunoCompleto, alunoCompleto, conteudo);
}

function gerarPDFResultadoAluno(alunoCompleto) {
  var dados = _lerAba_("Resultado_Final");
  var mat = extrairMatricula_(alunoCompleto);
  var regs = dados.filter(function(r){ return extrairMatricula_(r[0]) === mat; });
  // Resultado_Final: A=Aluno(0) B=Disciplina(1) ... — ordena por código da disciplina
  ordenarPorCodigoDisciplina_(regs, 1);

  var conteudo;
  if (regs.length === 0) {
    conteudo = '<div class="vazio">Nenhum resultado encontrado. Execute "Resultado final".</div>';
  } else {
    var linhas = "";
    regs.forEach(function(r) {
      var sit = String(r[4]); var cor = "#FFFFFF";
      if (sit === "APROVADO")                       cor = "#E2EFDA";
      if (sit === "PENDÊNCIA POR NOTA")             cor = "#FFF2CC";
      if (sit === "PENDÊNCIA POR FALTA")            cor = "#FCE4D6";
      if (sit === "PENDÊNCIA POR NOTA E PRESENÇA")  cor = "#FCE4D6";
      linhas += '<tr style="background:'+cor+'"><td>'+r[1]+'</td>'
              + '<td style="text-align:center">'+r[2]+'</td><td style="text-align:center">'+r[3]+'</td>'
              + '<td style="font-weight:bold">'+sit+'</td></tr>';
    });
    conteudo = '<table><thead><tr><th>Disciplina</th><th style="text-align:center">Média</th>'
             + '<th style="text-align:center">% Frequência</th><th>Situação</th></tr></thead><tbody>'
             + linhas + '</tbody></table>';
  }
  _abrirRelatorioHTML_("Resultado Final — " + alunoCompleto, alunoCompleto, conteudo);
}

function gerarPDFHistoricoAluno(alunoCompleto) {
  var ui = SpreadsheetApp.getUi();
  if (!alunoCompleto) {
    var r = ui.prompt("Histórico", "Digite a matrícula (ex: IBTR-001):", ui.ButtonSet.OK_CANCEL);
    if (r.getSelectedButton() != ui.Button.OK) return;
    alunoCompleto = r.getResponseText().trim();
  }
  var dados = _lerAba_("Historico_Consolidado");
  var mat = extrairMatricula_(alunoCompleto);
  var regs = dados.filter(function(r){ return extrairMatricula_(r[1]) === mat; });
  var nomeAluno = regs.length > 0 ? regs[0][1] : alunoCompleto;

  // Historico_Consolidado: A=Ano(0) B=Aluno(1) C=Disciplina(2) ...
  // Ordena por CÓDIGO da disciplina (IBTR-D01, D02, ...), depois por ano.
  regs.sort(function(a, b) {
    function num(v) { var m = String(v||"").toUpperCase().match(/IBTR-D(\d+)/); return m ? parseInt(m[1],10) : 999999; }
    var na = num(a[2]), nb = num(b[2]);
    if (na !== nb) return na - nb;
    return String(a[0]).localeCompare(String(b[0]), "pt");   // desempate por ano
  });

  var conteudo;
  if (regs.length === 0) {
    conteudo = '<div class="vazio">Nenhum histórico encontrado. Execute "Arquivar disciplina".</div>';
  } else {
    var linhas = "", aprov = 0, pend = 0;
    regs.forEach(function(r) {
      var sit = String(r[8]); var cor = "#FFFFFF";
      if (sit === "APROVADO")                       { cor = "#E2EFDA"; aprov++; }
      if (sit === "PENDÊNCIA POR NOTA")             { cor = "#FFF2CC"; pend++; }
      if (sit === "PENDÊNCIA POR FALTA")            { cor = "#FCE4D6"; pend++; }
      if (sit === "PENDÊNCIA POR NOTA E PRESENÇA")  { cor = "#FCE4D6"; pend++; }
      linhas += '<tr style="background:'+cor+'"><td>'+r[0]+'</td><td>'+r[2]+'</td>'
              + '<td style="text-align:center">'+r[3]+'</td><td style="text-align:center">'+r[5]+'</td>'
              + '<td style="text-align:center">'+r[6]+'</td><td style="text-align:center">'+r[7]+'</td>'
              + '<td style="font-weight:bold">'+sit+'</td></tr>';
    });
    conteudo = '<table><thead><tr><th>Ano</th><th>Disciplina</th>'
             + '<th style="text-align:center">Avaliação</th><th style="text-align:center">Presenças</th>'
             + '<th style="text-align:center">Tempos registrados</th><th style="text-align:center">% Frequência</th>'
             + '<th>Situação</th></tr></thead><tbody>'+linhas+'</tbody></table>'
             + '<div class="resumo"><strong>Total:</strong> '+regs.length
             + ' &nbsp;|&nbsp; <strong>Aprovado:</strong> '+aprov
             + ' &nbsp;|&nbsp; <strong>Pendências:</strong> '+pend+'</div>';
  }
  _abrirRelatorioHTML_("Histórico — " + nomeAluno, nomeAluno, conteudo);
}


// =====================================================
// PDFs de aba completa (frequência/notas/resultado gerais)
// via export PDF do Google — inalterado, mantém triggers de reocultar
// =====================================================
function prepararPDFAba_(nomeAba) {
  var planilha = SpreadsheetApp.getActiveSpreadsheet();
  var aba = planilha.getSheetByName(nomeAba);
  if (!aba) return { erro: "Aba '" + nomeAba + "' não encontrada." };

  if (aba.isSheetHidden()) {
    aba.showSheet();
    var props = PropertiesService.getScriptProperties();
    var lista = (props.getProperty("ABAS_REOCULTAR") || "").split(",").filter(String);
    if (lista.indexOf(nomeAba) === -1) lista.push(nomeAba);
    props.setProperty("ABAS_REOCULTAR", lista.join(","));
    ScriptApp.getProjectTriggers().forEach(function(t){
      if (t.getHandlerFunction() === "reocultarAbas_") ScriptApp.deleteTrigger(t);
    });
    ScriptApp.newTrigger("reocultarAbas_").timeBased().after(60000).create();
  }

  var url = "https://docs.google.com/spreadsheets/d/" + planilha.getId() +
    "/export?format=pdf&gid=" + aba.getSheetId() +
    "&portrait=false&fitw=true&sheetnames=false&printtitle=false&pagenumbers=true&gridlines=false&fzr=false";
  return { url: url, nomeAba: nomeAba };
}

function reocultarAbas_() {
  ScriptApp.getProjectTriggers().forEach(function(t){
    if (t.getHandlerFunction() === "reocultarAbas_") ScriptApp.deleteTrigger(t);
  });
  var props = PropertiesService.getScriptProperties();
  var listaStr = props.getProperty("ABAS_REOCULTAR") || "";
  if (!listaStr) return;
  var planilha = SpreadsheetApp.getActiveSpreadsheet();
  listaStr.split(",").forEach(function(nome){
    var aba = planilha.getSheetByName(nome.trim());
    if (aba) aba.hideSheet();
  });
  props.deleteProperty("ABAS_REOCULTAR");
}

function gerarPDFFrequencia() { return prepararPDFAba_("Frequencia_Consolidada"); }
function gerarPDFNotas()      { return prepararPDFAba_("Notas_Consolidadas"); }
function gerarPDFResultado()  { return prepararPDFAba_("Resultado_Final"); }

// =====================================================
// PDF — PRESENÇAS DO DIA
// Lê Form_Respostas_Presenca e filtra pelo dia escolhido.
// Mostra: aluno, tempo, presente/falta, status.
// Acessível pelo sidebar sem desocultar a aba.
// Aceita dataStr opcional (dd/MM/yyyy); padrão = hoje.
// =====================================================
function gerarPDFPresencasDia(dataStr) {
  var planilha = SpreadsheetApp.getActiveSpreadsheet();
  var tz       = Session.getScriptTimeZone();

  // Data alvo: parâmetro do sidebar ou hoje como fallback
  var diaAlvo;
  if (dataStr && dataStr.trim()) {
    var p = dataStr.trim().split("/");
    var d = new Date(p[2], p[1] - 1, p[0], 12, 0, 0);
    diaAlvo = Utilities.formatDate(d, tz, "dd/MM/yyyy");
  } else {
    diaAlvo = Utilities.formatDate(new Date(), tz, "dd/MM/yyyy");
  }

  var disciplina = obterDisciplinaAtiva_();
  if (!disciplina) return;

  // Lê a aba mesmo que esteja oculta
  var dados = _lerAba_("Form_Respostas_Presenca");

  // Filtra só o dia escolhido e a disciplina ativa
  var registros = dados.filter(function(r) {
    var d = converterTimestamp_(r[0]);
    var dia = Utilities.formatDate(d, tz, "dd/MM/yyyy");
    return dia === diaAlvo && normalizar_(nomePuroDisciplina_(r[1])) === normalizar_(nomePuroDisciplina_(disciplina));
  });

  if (registros.length === 0) {
    _abrirRelatorioHTML_(
      "Presenças do dia — " + diaAlvo,
      disciplina,
      '<div class="vazio">Nenhum registro para ' + diaAlvo + '.<br>Os alunos ainda não marcaram presença ou a aula não foi iniciada.</div>'
    );
    return;
  }

  // Ordena por aluno (col C = índice 2) alfabeticamente pelo NOME
  registros.sort(function(a, b) {
    return limparNome_(String(a[2]).replace(/^\s*IBTR-\d+\s*[—\-]*\s*/i, ""))
      .localeCompare(limparNome_(String(b[2]).replace(/^\s*IBTR-\d+\s*[—\-]*\s*/i, "")), "pt");
  });

  // Contadores
  var p1 = 0, p2 = 0, f1 = 0, f2 = 0, foraDH = 0, dupl = 0, abon = 0;

  var linhas = "";
  registros.forEach(function(r) {
    var hora    = Utilities.formatDate(converterTimestamp_(r[0]), tz, "HH:mm:ss");
    var aluno   = String(r[2]);
    var tempo   = String(r[3]);
    var presente = String(r[4]);
    var status  = String(r[5] || "");
    var motivo  = String(r[6] || "");

    // Cor da linha por status
    var corLinha = "#FFFFFF";
    var corStatus = "#202124";
    if (status === "FORA_DO_HORARIO") { corLinha = "#FFF2CC"; corStatus = "#B45309"; foraDH++; }
    else if (status === "DUPLICADA")  { corLinha = "#FCE4D6"; corStatus = "#C5221F"; dupl++; }
    else if (status === "ABONADA")    { corLinha = "#F2CDCD"; corStatus = "#8B0000"; abon++; }
    else if (status === "FALTA")      { corLinha = "#FCE4D6"; corStatus = "#C5221F"; }
    else if (status === "VALIDA" || status === "MANUAL") {
      corLinha = "#E2EFDA"; corStatus = "#1E5C0A";
    }

    // Contadores de presença real (válida/manual)
    if (presente === "Sim" && (status === "VALIDA" || status === "MANUAL")) {
      if (tempo === "1º Tempo") p1++;
      if (tempo === "2º Tempo") p2++;
    }
    if (presente === "Não" && status === "FALTA") {
      if (tempo === "1º Tempo") f1++;
      if (tempo === "2º Tempo") f2++;
    }

    // Ícone de presença
    var icone = presente === "Sim" ? "✅" : "❌";
    var statusLabel = status || "—";

    linhas +=
      '<tr style="background:' + corLinha + '">' +
      '<td>' + hora + '</td>' +
      '<td>' + aluno + '</td>' +
      '<td style="text-align:center">' + tempo + '</td>' +
      '<td style="text-align:center">' + icone + ' ' + presente + '</td>' +
      '<td style="font-weight:bold;color:' + corStatus + '">' + statusLabel + '</td>' +
      '<td style="font-size:10px">' + (motivo || '—') + '</td>' +
      '</tr>';
  });

  var conteudo =
    '<table><thead><tr>' +
    '<th>Hora</th><th>Aluno</th>' +
    '<th style="text-align:center">Tempo</th>' +
    '<th style="text-align:center">Presença</th>' +
    '<th>Status</th>' +
    '<th>Motivo (se abonada)</th>' +
    '</tr></thead><tbody>' + linhas + '</tbody></table>' +
    '<div class="resumo">' +
    '<strong>Disciplina:</strong> ' + disciplina + '<br>' +
    '<strong>1º Tempo:</strong> ' + p1 + ' presente(s) / ' + f1 + ' falta(s)' +
    ' &nbsp;|&nbsp; <strong>2º Tempo:</strong> ' + p2 + ' presente(s) / ' + f2 + ' falta(s)' +
    (abon > 0   ? ' &nbsp;|&nbsp; <span style="color:#8B0000"><strong>📋 Faltas abonadas: ' + abon + '</strong></span>' : '') +
    (foraDH > 0 ? ' &nbsp;|&nbsp; <span style="color:#B45309"><strong>⚠ Fora do horário: ' + foraDH + '</strong></span>' : '') +
    (dupl > 0   ? ' &nbsp;|&nbsp; <span style="color:#C5221F"><strong>⚠ Duplicadas: ' + dupl + '</strong></span>' : '') +
    '</div>' +
    '<div class="resumo" style="margin-top:8px;background:#FBF0F0;color:#8B0000;font-size:10px">' +
    '🟢 VÁLIDA / MANUAL = presença conta &nbsp;|&nbsp; 🔴 FALTA = ausência registrada &nbsp;|&nbsp; 🔵 ABONADA = falta justificada, não conta na frequência &nbsp;|&nbsp; 🟡 FORA_DO_HORARIO = marcou mas não conta &nbsp;|&nbsp; 🔴 DUPLICADA = marcou duas vezes' +
    '</div>';

  _abrirRelatorioHTML_("Presenças do dia — " + diaAlvo, disciplina, conteudo);
}

function _gerarPDFPresencasDia(dataStr) { gerarPDFPresencasDia(dataStr); return "ok"; }

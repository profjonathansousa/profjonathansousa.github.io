// =====================================================
// IBTRADCA — 03_arquivar_professores.js
// Versão 5.0
//
// CORRIGE:
//  - Coluna G (Total_Tempos) do Historico_Consolidado:
//    explicado abaixo. A coluna soma o TOTAL DE TEMPOS do
//    aluno na disciplina (presenças + faltas), vindo de
//    Frequencia_Consolidada coluna E. Antes vinha 0 porque o
//    cruzamento nota×frequência falhava (nome). Agora cruza por
//    matrícula, então o Total aparece corretamente.
//
// ADICIONA:
//  - Cadastro de Professores (aba Cadastro_Professores)
//  - PDF de relatório de professores
// =====================================================


// =====================================================
// ARQUIVAR DISCIPLINA — cruzamento por matrícula
// Historico_Consolidado:
//   A=Ano B=Aluno C=Disciplina D=Avaliacao E=Media
//   F=Presencas G=Total_Tempos H=Frequencia% I=Situacao
// =====================================================
function arquivarDisciplina() {
  var planilha = SpreadsheetApp.getActiveSpreadsheet();
  var ui       = SpreadsheetApp.getUi();

  var disciplina = obterDisciplinaAtiva_();
  if (!disciplina) return;

  var confirma = ui.alert("Arquivar disciplina",
    "Arquivar:\n\n" + disciplina + "\n\n" +
    "✔ Grava resultado de cada aluno no Histórico\n" +
    "✔ Marca a disciplina como Inativo\n\nConfirmar?",
    ui.ButtonSet.YES_NO);
  if (confirma != ui.Button.YES) { ui.alert("Arquivamento cancelado."); return; }

  // Notas
  var dadosNotas = planilha.getSheetByName("Notas_Consolidadas").getDataRange().getValues();
  dadosNotas.shift();
  var mapaNotas = {};
  dadosNotas.forEach(function(l) {
    if (normalizar_(l[1]) != normalizar_(disciplina)) return;
    var mat = extrairMatricula_(l[0]);
    if (!mat) return;
    mapaNotas[mat] = { alunoCompleto: String(l[0]).trim(), media: l[4] };
  });

  // Frequência
  var dadosFreq = planilha.getSheetByName("Frequencia_Consolidada").getDataRange().getValues();
  dadosFreq.shift();
  var mapaFreq = {};
  dadosFreq.forEach(function(l) {
    if (normalizar_(l[0]) != normalizar_(disciplina)) return;
    var mat = extrairMatricula_(l[1]);
    if (!mat) return;
    mapaFreq[mat] = { presencas: l[2], total: l[4], freqStr: l[5] };
  });

  var ano = new Date().getFullYear();

  // Lê o Histórico ANTES de calcular o que seria novo, para saber
  // quais alunos já têm um registro para esta disciplina+ano.
  var abaHist   = planilha.getSheetByName("Historico_Consolidado");
  var dadosHist = abaHist.getDataRange().getValues();

  // matricula → { linha (índice 0-based no array dados), dados (array da linha) }
  var registrosExistentes = {};
  for (var h = 1; h < dadosHist.length; h++) {
    if (String(dadosHist[h][0]) != String(ano)) continue;
    if (normalizar_(String(dadosHist[h][2])) != normalizar_(disciplina)) continue;
    var matExistente = extrairMatricula_(String(dadosHist[h][1]));
    if (matExistente) registrosExistentes[matExistente] = { idx: h, linha: dadosHist[h] };
  }

  var novas = [], semFreq = [], preservados = [], notasAtualizadas = [];
  var criterios = obterCriteriosAcademicos_();

  Object.keys(mapaNotas).forEach(function(mat) {
    var n = mapaNotas[mat];
    var f = mapaFreq[mat];

    var existente = registrosExistentes[mat];

    if (existente) {
      // Já existe registro (importado ou arquivado antes).
      // FREQUÊNCIA: sempre preservada, nunca recalculada aqui.
      // NOTA: só é atualizada se a nota existente estiver zerada
      // (professor ainda não tinha lançado quando o histórico foi
      // gravado). Nota real (>0) nunca é sobrescrita.
      var notaExistente = Number(existente.linha[3]) || 0;

      if (notaExistente > 0) {
        preservados.push(mat);
        return;  // nada muda nesta linha
      }

      // Nota existente é 0 → aceita a nota nova, mantém frequência
      var notaNova    = Number(n.media);
      var presencasOk = Number(existente.linha[5]) || 0;
      var totalOk      = Number(existente.linha[6]) || 0;
      var freqStrOk    = existente.linha[7];
      var freqNumOk    = parseFloat(String(freqStrOk).replace("%", "").replace(",", "."));

      var sitNova;
      if (totalOk === 0 && freqNumOk === 0)      sitNova = "PENDÊNCIA POR NOTA E PRESENÇA";
      else if (freqNumOk < criterios.freqMinima) sitNova = "PENDÊNCIA POR FALTA";
      else if (notaNova >= criterios.notaMinima) sitNova = "APROVADO";
      else                                        sitNova = "PENDÊNCIA POR NOTA";

      // Atualiza só as colunas D (Avaliacao), E (Media) e I (Situacao)
      // na linha existente — F,G,H (presenças/total/freq) intocadas.
      abaHist.getRange(existente.idx + 1, 4).setValue(notaNova);  // D
      abaHist.getRange(existente.idx + 1, 5).setValue(notaNova);  // E
      abaHist.getRange(existente.idx + 1, 9).setValue(sitNova);   // I

      var corSit = "#FFFFFF";
      if (sitNova === "APROVADO")                       corSit = "#E2EFDA";
      if (sitNova === "PENDÊNCIA POR NOTA")             corSit = "#FFF2CC";
      if (sitNova === "PENDÊNCIA POR FALTA")            corSit = "#FCE4D6";
      if (sitNova === "PENDÊNCIA POR NOTA E PRESENÇA")  corSit = "#FCE4D6";
      abaHist.getRange(existente.idx + 1, 9).setBackground(corSit);

      notasAtualizadas.push(mat);
      return;
    }

    // Nenhum registro existente: fluxo normal, grava linha nova
    if (!f) semFreq.push(mat);

    var media     = Number(n.media);
    var presencas = f ? f.presencas : 0;
    var total     = f ? f.total     : 0;     // Total_Tempos = presenças + faltas
    var freqStr   = f ? f.freqStr   : "0%";
    var freqNum   = parseFloat(String(freqStr).replace("%", "").replace(",", "."));

    var sit;
    if (freqNum < criterios.freqMinima)    sit = "PENDÊNCIA POR FALTA";
    else if (media >= criterios.notaMinima) sit = "APROVADO";
    else                                     sit = "PENDÊNCIA POR NOTA";

    novas.push([ano, n.alunoCompleto, disciplina, media, media, presencas, total, freqStr, sit]);
  });

  if (novas.length == 0) {
    if (preservados.length > 0 || notasAtualizadas.length > 0) {
      var msgResumo = "";
      if (notasAtualizadas.length > 0) msgResumo += notasAtualizadas.length + " nota(s) atualizada(s) (frequência preservada).\n";
      if (preservados.length > 0)      msgResumo += preservados.length + " aluno(s) com nota já lançada — nada alterado.\n";

      var confInativar = ui.alert(
        "Nenhum registro novo para arquivar",
        msgResumo + "\nDeseja marcar a disciplina como Inativo mesmo assim?",
        ui.ButtonSet.YES_NO
      );
      if (confInativar === ui.Button.YES) {
        var abaDiscPreservado = planilha.getSheetByName("Cadastro_Disciplinas");
        var dDiscPreservado   = abaDiscPreservado.getDataRange().getValues();
        for (var dp = 1; dp < dDiscPreservado.length; dp++) {
          if (normalizar_(dDiscPreservado[dp][0] + " — " + dDiscPreservado[dp][1]) == normalizar_(disciplina)) {
            abaDiscPreservado.getRange(dp + 1, 6).setValue("Inativo");
            break;
          }
        }
        ui.alert("Disciplina marcada como Inativo.");
      }
    } else {
      ui.alert("Nenhum dado encontrado.\nExecute Consolidar Notas e Consolidar Frequência antes.");
    }
    return;
  }

  var ult = abaHist.getLastRow();
  abaHist.getRange(ult + 1, 1, novas.length, 9).setValues(novas);

  // Força coluna H (% Frequência) como texto puro — evita que o Sheets
  // reinterprete "100.0%" como o número decimal 1
  abaHist.getRange(ult + 1, 8, novas.length, 1).setNumberFormat("@");

  for (var r = 0; r < novas.length; r++) {
    var cor = "#FFFFFF";
    if (novas[r][8] == "APROVADO")            cor = "#E2EFDA";
    if (novas[r][8] == "PENDÊNCIA POR NOTA")  cor = "#FFF2CC";
    if (novas[r][8] == "PENDÊNCIA POR FALTA") cor = "#FCE4D6";
    abaHist.getRange(ult + 1 + r, 9).setBackground(cor);
  }

  // Inativa disciplina
  var abaDisc = planilha.getSheetByName("Cadastro_Disciplinas");
  var dDisc   = abaDisc.getDataRange().getValues();
  for (var d = 1; d < dDisc.length; d++) {
    if (normalizar_(dDisc[d][0] + " — " + dDisc[d][1]) == normalizar_(disciplina)) {
      abaDisc.getRange(d + 1, 6).setValue("Inativo"); break;
    }
  }

  var alertas = semFreq.length > 0 ? "\n⚠ Sem frequência: " + semFreq.length + " aluno(s)" : "";
  var msgPreservados = preservados.length > 0
    ? "\n🔒 " + preservados.length + " aluno(s) já tinham nota lançada e foram preservados"
    : "";
  var msgAtualizados = notasAtualizadas.length > 0
    ? "\n📝 " + notasAtualizadas.length + " nota(s) atualizada(s) (frequência importada preservada)"
    : "";
  ui.alert("Disciplina arquivada!",
    disciplina + "\n\n✔ " + novas.length + " aluno(s) novo(s) arquivado(s)\n✔ Marcada como Inativo" +
    msgAtualizados + msgPreservados + alertas,
    ui.ButtonSet.OK);
}


function consultarHistoricoAluno() {
  var planilha = SpreadsheetApp.getActiveSpreadsheet();
  var ui       = SpreadsheetApp.getUi();
  var r = ui.prompt("Consultar histórico", "Digite a matrícula (ex: IBTR-001):", ui.ButtonSet.OK_CANCEL);
  if (r.getSelectedButton() != ui.Button.OK) return;

  var matricula = extrairMatricula_(r.getResponseText());
  var dados = planilha.getSheetByName("Historico_Consolidado").getDataRange().getValues();
  dados.shift();

  var regs = dados.filter(function(l) { return extrairMatricula_(l[1]) === matricula; });
  if (regs.length == 0) { ui.alert("Nenhum registro para " + matricula); return; }

  var msg = "Histórico de " + matricula + ":\n\n";
  regs.forEach(function(r) {
    msg += r[0] + " | " + r[2] + "\n     Média: " + r[4] + " | Freq: " + r[7] + " | " + r[8] + "\n\n";
  });
  ui.alert("Histórico do aluno", msg, ui.ButtonSet.OK);
}


// =====================================================
// CADASTRO DE PROFESSORES
// Aba Cadastro_Professores:
//   A=Codigo B=Nome C=Titulacao D=Disciplinas E=Contato F=Situacao
// =====================================================
function garantirAbaProfessores_() {
  var planilha = SpreadsheetApp.getActiveSpreadsheet();
  var aba = planilha.getSheetByName("Cadastro_Professores");
  if (!aba) {
    aba = planilha.insertSheet("Cadastro_Professores");
    aba.getRange(1, 1, 1, 6).setValues([[
      "Codigo", "Nome", "Titulacao", "Disciplinas", "Contato", "Situacao"
    ]]);
    aba.getRange(1, 1, 1, 6)
      .setBackground("#B40000").setFontColor("#FFFFFF").setFontWeight("bold");
    aba.setFrozenRows(1);
  }
  return aba;
}

// =====================================================
// PDF — TODOS OS PROFESSORES (ordenado, ativos/inativos)
// =====================================================
function gerarPDFTodosProfessores() {
  var aba = garantirAbaProfessores_();
  var dados = aba.getDataRange().getValues();
  dados.shift();

  var ativos   = dados.filter(function(r){ return String(r[5]).trim() === "Ativo"; });
  var inativos = dados.filter(function(r){ return String(r[5]).trim() !== "Ativo"; });

  function ordenar(arr){ return arr.sort(function(a,b){ return String(a[1]).localeCompare(String(b[1]),"pt"); }); }
  ordenar(ativos); ordenar(inativos);

  function bloco(arr, titulo, cor){
    if (arr.length === 0) return "";
    var html = '<tr><td colspan="5" style="background:'+cor+';color:#fff;font-weight:bold;padding:6px 8px;font-size:11px;">'
             + titulo + ' (' + arr.length + ')</td></tr>';
    arr.forEach(function(r, idx){
      var bg = idx % 2 === 0 ? "#FFFFFF" : "#F1F3F4";
      html += '<tr style="background:'+bg+'">'
            + '<td>'+r[0]+'</td><td>'+r[1]+'</td><td>'+(r[2]||"—")+'</td>'
            + '<td>'+(r[3]||"—")+'</td><td>'+(r[4]||"—")+'</td></tr>';
    });
    return html;
  }

  var linhas = bloco(ativos,"Ativos","#B40000") + bloco(inativos,"Inativos","#80868B");
  var resumo = '<div class="resumo"><strong>Total:</strong> '+dados.length
             + ' &nbsp;|&nbsp; <strong>Ativos:</strong> '+ativos.length
             + ' &nbsp;|&nbsp; <strong>Inativos:</strong> '+inativos.length+'</div>';
  var tabela = '<table><thead><tr><th>Código</th><th>Nome</th><th>Titulação</th>'
             + '<th>Disciplinas</th><th>Contato</th></tr></thead><tbody>'
             + linhas + '</tbody></table>' + resumo;

  _abrirRelatorioHTML_("Cadastro de Professores", "Todos os professores", tabela);
}


// =====================================================
// WRAPPERS
// =====================================================
// Consulta de histórico chamada pelo sidebar (recebe aluno completo)
function consultarHistoricoAlunoSidebar(alunoCompleto) {
  var ui = SpreadsheetApp.getUi();
  var matricula = extrairMatricula_(alunoCompleto);
  var dados = SpreadsheetApp.getActiveSpreadsheet()
                .getSheetByName("Historico_Consolidado").getDataRange().getValues();
  dados.shift();
  var regs = dados.filter(function(l){ return extrairMatricula_(l[1]) === matricula; });
  if (regs.length == 0) {
    ui.alert("Nenhum histórico para:\n" + alunoCompleto + "\n\nExecute 'Arquivar disciplina' primeiro.");
    return "ok";
  }
  var msg = "Histórico de " + alunoCompleto + ":\n\n";
  regs.forEach(function(r){
    msg += r[0] + " | " + r[2] + "\n     Média: " + r[4] + " | Freq: " + r[7] + " | " + r[8] + "\n\n";
  });
  ui.alert("Histórico do aluno", msg, ui.ButtonSet.OK);
  return "ok";
}

function _arquivarDisciplina()      { arquivarDisciplina();       return "ok"; }
function _gerarPDFTodosProfessores(){ gerarPDFTodosProfessores(); return "ok"; }
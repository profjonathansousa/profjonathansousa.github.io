// =====================================================
// IBTRADCA — 06_importar_historico.js
// Versão 1.0
//
// IMPORTA dados históricos de um Excel para o sistema.
// Opera em DOIS MODOS:
//
//   previsualizarImportacao()  → só lê e gera relatório HTML
//                                mostrando o que SERIA importado.
//                                NÃO grava nada.
//
//   executarImportacao()       → após revisar a prévia,
//                                grava de fato no sistema.
//
// O Excel deve estar na pasta raiz do Google Drive
// com o nome exato definido em NOME_ARQUIVO_EXCEL abaixo.
// =====================================================

var NOME_ARQUIVO_EXCEL = "IBTR_ULTIMO_Padronizac_a_o_de_Gastos_Entrada_e_Saida_Notas_e_Frequencia__fRFrequencia_PG_Total_Correta.xlsx";

// Abas do Excel que NÃO são acadêmicas (financeiro, pagamento etc.)
var ABAS_IGNORAR = [
  ' SAIDA SEMINÁRIO JULHO ',
  'Entrada Seminário JUlHO ',
  ' PAGAMENTOTotal ',
  'Pg Seminario OUT ',
  'PLANILHA FINAL ',
  'GASTOS SEMIN ABRIL',
  'PG SEMIN ABRIL',
  'LIÇÃO EBD e CURSO DE DIACONOS ',
  'teste',
  'Gastos do Semin de Maio ',
  'Pg Seminario de Maio'
];

// Valores de presença que significam que aquela aula
// simplesmente não existia para o aluno (entrou depois, etc.)
// → não contam como falta nem como presença
var VALORES_NAO_CONTAM = [
  'nao estava matric',
  'nao havia iniciado',
  'nao hava iniciado',
  'nao estava matriculada',
  'nao estava matriculado',
  'não estava matric',
  'nao estava matric ainda',
];

// Valores que indicam que o aluno SAIU do curso
var VALORES_SAIU = ['saiu', 'saiu '];

// Limiar de similaridade para casamento de nomes (0–1)
// 0.85 = aceita pequenas diferenças (ponto final, espaço, acento)
var LIMIAR_SIMILARIDADE = 0.82;

// =====================================================
// MAPEAMENTO MANUAL DE DISCIPLINAS
//
// Para casos em que o nome usado no Excel é completamente
// diferente do nome cadastrado no sistema (não é erro de
// digitação, é outro nome mesmo) — a similaridade textual
// nunca vai resolver isso, então mapeamos manualmente.
//
// Chave   = nome normalizado como aparece no Excel
// Valor   = código oficial em Cadastro_Disciplinas (IBTR-DNN)
//
// Para adicionar um novo apelido: normalize o nome do Excel
// (sem acento, maiúsculo, sem pontuação) e aponte para o código.
// =====================================================
var MAPEAMENTO_MANUAL_DISCIPLINAS = {
  "TEOLOGIA SISTEMATICA I":   "IBTR-D07",
  "TEOLOGIA SISTEMATICA II":  "IBTR-D08",
  "TEOLOGIA SISTEMATICA III": "IBTR-D09",
  "TEOLOGIA SISTEMATICA IV":  "IBTR-D10",
  "TEOLOGIA SISTEMATICA V":   "IBTR-D11",
  "SINTESE DO AT I":          "IBTR-D13",
  "SINTESE DO AT II":         "IBTR-D14",
  "SINTESE DO NT I":          "IBTR-D15",
  "SINTESE DO NT II":         "IBTR-D16",
  "SINTESE DO NT III":        "IBTR-D17",
  // Nomes de aba abreviados que vazaram para o Histórico como fallback
  // antes da correção que impede isso (ver extracaoFalhou em
  // parsearAba_). Mantidos aqui para resolver retroativamente os
  // registros já importados com esses nomes.
  "FREQU PORTUGUES":          "IBTR-D01",
  "FREQ PANORAMA BIBLICO":    "IBTR-D02",
  "FREQ HERMENEUTICA":        "IBTR-D03",
  "FREQ PSICOLOGIA PATORAL":  "IBTR-D04",
  "HIST DO CRISTIANISMO":     "IBTR-D05"
};


// =====================================================
// UTILITÁRIOS DE TEXTO
// =====================================================
function normalizarNome_(n) {
  if (!n) return "";
  return n.toString()
    .normalize("NFD").replace(/[\u0300-\u036f]/g, "")  // remove acentos
    .replace(/[.,\-]/g, " ")                             // ponto, vírgula e traço → espaço
    .replace(/\s+/g, " ")
    .trim()
    .toUpperCase();
}

// Similaridade de Jaccard por bigramas — rápida e boa para nomes
function similaridade_(a, b) {
  a = normalizarNome_(a);
  b = normalizarNome_(b);
  if (a === b) return 1;
  if (!a || !b) return 0;

  function bigramas(s) {
    var bg = {};
    for (var i = 0; i < s.length - 1; i++) {
      var bg2 = s.slice(i, i + 2);
      bg[bg2] = (bg[bg2] || 0) + 1;
    }
    return bg;
  }

  var ba = bigramas(a), bb = bigramas(b);
  var inter = 0, uniao = 0;
  var todas = {};
  Object.keys(ba).forEach(function(k) { todas[k] = true; });
  Object.keys(bb).forEach(function(k) { todas[k] = true; });
  Object.keys(todas).forEach(function(k) {
    var qa = ba[k] || 0, qb = bb[k] || 0;
    inter += Math.min(qa, qb);
    uniao += Math.max(qa, qb);
  });
  return uniao === 0 ? 0 : inter / uniao;
}

function isNaoContam_(val) {
  var v = normalizarNome_(String(val || ""));
  return VALORES_NAO_CONTAM.some(function(x) {
    return v.indexOf(normalizarNome_(x)) === 0 || v.indexOf(normalizarNome_(x)) > -1;
  });
}

function isSaiu_(val) {
  var v = String(val || "").trim().toLowerCase();
  return VALORES_SAIU.indexOf(v) > -1;
}

function extrairAno_(linhas) {
  for (var i = 0; i < Math.min(3, linhas.length); i++) {
    var txt = linhas[i].join(" ");
    var m = txt.match(/20(2[4-9]|3\d)/);
    if (m) return parseInt(m[0]);
  }
  return new Date().getFullYear();
}

function extrairNomeDiscplina_(linhas) {
  // O texto "FREQUENCIA DISCIPLINA: ..." pode estar em qualquer coluna
  // da linha 1 (varia entre os layouts antigo e novo do Excel).
  var l1 = "";
  if (linhas.length > 0) {
    for (var c = 0; c < linhas[0].length; c++) {
      var v = String(linhas[0][c] || "");
      if (v.toUpperCase().indexOf("DISCIPLINA") > -1) { l1 = v; break; }
    }
  }
  if (!l1) return "";

  // Extrai o trecho entre "DISCIPLINA :" e o que vem depois.
  // Dois padrões de fim observados no Excel:
  //   "...DISCIPLINA : NOME   PROFESSOR: FULANO"   → corta em "PROFESSOR"
  //   "...DISCIPLINA : NOME : FULANO"              → corta no 2º ":"
  var m = l1.match(/DISCIPLINA\s*[:\-]\s*(.+)/i);
  if (!m) return l1.trim();

  var resto = m[1];

  // Corta a partir de "PROFESSOR" se existir
  var idxProf = resto.toUpperCase().indexOf("PROFESSOR");
  if (idxProf > -1) resto = resto.slice(0, idxProf);

  // Corta a partir de um ":" remanescente (separador "Nome : Professor")
  var idxDoisPontos = resto.indexOf(":");
  if (idxDoisPontos > -1) resto = resto.slice(0, idxDoisPontos);

  return resto.replace(/\s+/g, " ").trim();
}

function temNumCol_(linhas) {
  // Layout A (2024): col A da linha 3 é "Nº"
  if (linhas.length < 3) return false;
  var v = String(linhas[2][0] || "").trim().replace(/°/g, "º");
  return v === "Nº" || v === "N°" || v === "N" || v === "Nº";
}


// =====================================================
// ABRIR ARQUIVO EXCEL DO DRIVE
// Estratégia: copia o arquivo Excel dentro do Drive
// convertendo para Google Sheets via DriveApp.
// Não precisa de nenhum serviço avançado nem Drive API v3.
// =====================================================
function abrirExcel_() {
  // 1) Localiza o arquivo Excel
  var arquivos = DriveApp.getFilesByName(NOME_ARQUIVO_EXCEL);
  if (!arquivos.hasNext()) {
    SpreadsheetApp.getUi().alert(
      "Arquivo não encontrado",
      "Não foi possível encontrar:\n\n" + NOME_ARQUIVO_EXCEL +
      "\n\nVerifique se o arquivo está na raiz do Google Drive\n" +
      "e se o nome está exatamente correto (incluindo extensão .xlsx).",
      SpreadsheetApp.getUi().ButtonSet.OK
    );
    return null;
  }

  var arquivo = arquivos.next();

  // 2) Cria uma cópia já convertida para Google Sheets
  //    DriveApp.File.makeCopy() com mimeType GOOGLE_SHEETS
  //    é o jeito nativo — não precisa de API avançada
  var pasta  = DriveApp.getRootFolder();
  var copia  = arquivo.makeCopy("__ibtr_import_tmp__", pasta);

  // 3) Converte o blob para Sheets via insert do próprio DriveApp
  //    Se makeCopy não converteu (ainda .xlsx), força a conversão
  var id = copia.getId();
  var mime = copia.getMimeType();

  if (mime !== MimeType.GOOGLE_SHEETS) {
    // Converte: lê como blob e re-cria como Sheets
    var blob = copia.getBlob().setContentType(
      "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
    );
    copia.setTrashed(true);  // descarta a cópia não convertida

    // Cria novo arquivo Sheets a partir do blob
    var nova = DriveApp.createFile(blob);
    nova.setName("__ibtr_import_tmp__");
    id = nova.getId();
  }

  try {
    return SpreadsheetApp.openById(id);
  } catch(e) {
    DriveApp.getFileById(id).setTrashed(true);
    SpreadsheetApp.getUi().alert(
      "Erro ao abrir conversão",
      "O arquivo foi convertido mas não pôde ser aberto.\nDetalhe: " + e.message,
      SpreadsheetApp.getUi().ButtonSet.OK
    );
    return null;
  }
}
function limparArquivoTemp_(ss) {
  try { DriveApp.getFileById(ss.getId()).setTrashed(true); } catch(e) {}
}


// =====================================================
// LER CADASTRO DE ALUNOS DO SISTEMA
// Retorna array de { matricula, nome, normNome, situacao }
// =====================================================
function lerCadastroAlunos_() {
  var planilha = SpreadsheetApp.getActiveSpreadsheet();
  var aba = planilha.getSheetByName("Cadastro_Alunos");
  if (!aba || aba.getLastRow() < 2) return [];
  var dados = aba.getRange(2, 1, aba.getLastRow() - 1, 4).getValues();
  return dados
    .filter(function(r) { return r[0]; })
    .map(function(r) {
      return {
        matricula: String(r[0]).trim(),
        nome:      String(r[1]).trim(),
        normNome:  normalizarNome_(r[1]),
        turma:     String(r[2]).trim(),
        situacao:  String(r[3]).trim()
      };
    });
}

// Próxima matrícula disponível
function proximaMatricula_(cadastro) {
  var max = 0;
  cadastro.forEach(function(a) {
    var m = a.matricula.match(/IBTR-(\d+)/);
    if (m) { var n = parseInt(m[1]); if (n > max) max = n; }
  });
  return "IBTR-" + String(max + 1).padStart(3, "0");
}


// =====================================================
// LER CADASTRO DE DISCIPLINAS DO SISTEMA
// Retorna array de { codigo, nome, normNome, situacao }
// =====================================================
function lerCadastroDisciplinas_() {
  var planilha = SpreadsheetApp.getActiveSpreadsheet();
  var aba = planilha.getSheetByName("Cadastro_Disciplinas");
  if (!aba || aba.getLastRow() < 2) return [];
  var dados = aba.getRange(2, 1, aba.getLastRow() - 1, 6).getValues();
  return dados
    .filter(function(r) { return r[0]; })
    .map(function(r) {
      return {
        codigo:    String(r[0]).trim(),
        nome:      String(r[1]).trim(),
        normNome:  normalizarNome_(r[1]),
        situacao:  String(r[5]).trim()
      };
    });
}

// Casar nome de disciplina do Excel com o Cadastro_Disciplinas.
// Ordem de checagem: 1) mapeamento manual, 2) exato, 3) similaridade.
function casarDisciplina_(nomeExcel, cadastroDisc) {
  var normExcel = normalizarNome_(nomeExcel);

  // 1) Mapeamento manual tem prioridade — resolve casos onde o nome
  //    do Excel é completamente diferente do nome no sistema.
  var codigoManual = MAPEAMENTO_MANUAL_DISCIPLINAS[normExcel];
  if (codigoManual) {
    var matchManual = cadastroDisc.find(function(d) { return d.codigo === codigoManual; });
    if (matchManual) {
      return { match: matchManual, tipo: "manual", sim: 1 };
    }
  }

  // 2) Casamento exato e 3) por similaridade
  var melhor = null, melhorSim = 0;

  for (var i = 0; i < cadastroDisc.length; i++) {
    if (cadastroDisc[i].normNome === normExcel) {
      return { match: cadastroDisc[i], tipo: "exato", sim: 1 };
    }
    var s = similaridade_(nomeExcel, cadastroDisc[i].nome);
    if (s > melhorSim) { melhorSim = s; melhor = cadastroDisc[i]; }
  }

  if (melhorSim >= LIMIAR_SIMILARIDADE) {
    return { match: melhor, tipo: "similar", sim: melhorSim };
  }
  return { match: null, tipo: "novo", sim: melhorSim };
}

// Casar nome do Excel com cadastro
// Retorna { match: objeto_aluno|null, tipo: 'exato'|'similar'|'novo', sim: float }
function casarNome_(nomeExcel, cadastro) {
  var normExcel = normalizarNome_(nomeExcel);
  var melhor = null, melhorSim = 0;

  for (var i = 0; i < cadastro.length; i++) {
    if (cadastro[i].normNome === normExcel) {
      return { match: cadastro[i], tipo: "exato", sim: 1 };
    }
    var s = similaridade_(nomeExcel, cadastro[i].nome);
    if (s > melhorSim) { melhorSim = s; melhor = cadastro[i]; }
  }

  if (melhorSim >= LIMIAR_SIMILARIDADE) {
    return { match: melhor, tipo: "similar", sim: melhorSim };
  }
  return { match: null, tipo: "novo", sim: melhorSim };
}


// =====================================================
// PARSEAR UMA ABA DO EXCEL
// Retorna array de registros:
// { nomeExcel, todosSaiu, temDados, presencas, faltas,
//   totalTempos, freqPct, notaRaw, nota, situacao, ano, disciplina }
// =====================================================
function parsearAba_(ws, nomeAba) {
  var rows = [];
  var range = ws.getDataRange().getValues();
  rows = range;

  if (rows.length < 5) return { disciplina: nomeAba, ano: 2024, registros: [] };

  var ano        = extrairAno_(rows);
  var nomeDiscExtraido = extrairNomeDiscplina_(rows);

  // NUNCA usa o nome da aba do Excel como disciplina silenciosamente —
  // isso gerava disciplinas "fantasma" como "Frequ Portugues" (nome
  // abreviado da aba) em vez do nome real extraído do cabeçalho
  // ("PORTUGUES"), que depois não casava com o Cadastro_Disciplinas
  // nem com o mapeamento manual, criando duplicatas no Histórico.
  var nomeDisc, extracaoFalhou;
  if (nomeDiscExtraido && nomeDiscExtraido.trim()) {
    nomeDisc = nomeDiscExtraido;
    extracaoFalhou = false;
  } else {
    nomeDisc = "⚠ NOME NÃO IDENTIFICADO (aba: " + nomeAba.trim() + ")";
    extracaoFalhou = true;
  }

  var temNum     = temNumCol_(rows);
  var colNome    = temNum ? 1 : 0;
  var colDadoIni = temNum ? 2 : 1;  // primeira coluna de presença
  var colNota    = -1;               // detectada abaixo

  // Detectar coluna da nota: última coluna com cabeçalho "Nota" em L3
  var cabec = rows[2];
  for (var c = cabec.length - 1; c >= 0; c--) {
    if (String(cabec[c] || "").trim().toUpperCase() === "NOTA") {
      colNota = c; break;
    }
  }
  // Fallback: penúltima coluna (antes de APROVADO/PENDENCIA)
  if (colNota < 0) colNota = cabec.length - 2;

  // Detectar número de colunas de presença (pares 1ºT/2ºT)
  // São todas as colunas entre colDadoIni e colNota (exclusive)
  var colPresFim = colNota - 1;

  var registros = [];
  var criterios = obterCriteriosAcademicos_();

  for (var r = 4; r < rows.length; r++) {
    var row = rows[r];
    if (!row || !row[colNome]) continue;

    var nomeRaw = String(row[colNome]).trim();
    if (!nomeRaw || nomeRaw.length < 3) continue;

    // Ignorar linhas de cabeçalho residuais
    var normN = nomeRaw.toUpperCase();
    if (normN === "NOME" || normN === "Nº" || normN.indexOf("DATA/MES") > -1) continue;

    // Verificar se é "SAIU" em todas as colunas
    var colunasPres = [];
    for (var cp = colDadoIni; cp <= colPresFim; cp++) {
      colunasPres.push(row[cp]);
    }

    var todosSaiu = colunasPres.every(function(v) { return isSaiu_(v); });

    // Contar presenças, faltas e ignorados
    var presencas = 0, faltas = 0, ignorados = 0;
    colunasPres.forEach(function(v) {
      var vs = String(v || "").trim().toLowerCase();
      if (isSaiu_(vs)) { /* saiu — conta abaixo */ }
      else if (isNaoContam_(vs)) { ignorados++; }
      else if (vs === "presente" || vs === "presente ") { presencas++; }
      else if (vs === "falta" || vs === "falta ") { faltas++; }
      // outros valores inesperados: ignorar
    });

    var totalTempos = presencas + faltas;
    var freqPct     = totalTempos > 0
      ? parseFloat((presencas / totalTempos * 100).toFixed(1))
      : 0;

    // Nota
    var notaRaw = row[colNota] !== undefined ? row[colNota] : null;
    var nota    = 0;
    var notaObs = "";

    if (notaRaw !== null && notaRaw !== undefined && String(notaRaw).trim() !== "") {
      var tentativa = parseFloat(String(notaRaw).replace(",", "."));
      if (!isNaN(tentativa)) {
        nota = tentativa;
      } else {
        // Nota textual: PT, Pendencia, Reprovado, SAIU etc.
        nota    = 0;
        notaObs = String(notaRaw).trim();
      }
    }

    // Situação
    var sit;
    var temNota = nota > 0;
    var temFreq = totalTempos > 0;

    if (todosSaiu && !temNota) {
      // SAIU sem qualquer dado → pular completamente
      continue;
    }

    if (!temFreq && !temNota && ignorados === 0) {
      // Linha completamente vazia: sem presença, sem falta, sem nota,
      // sem nenhuma marcação especial. Significa que a disciplina ainda
      // não tinha começado quando o Excel foi preenchido (aluno listado
      // na turma, mas a aula nunca ocorreu) — não é um dado real de
      // pendência, é ausência de dado. Não importa essa linha.
      continue;
    }

    if (!temFreq && !temNota) {
      sit = "PENDÊNCIA POR NOTA E PRESENÇA";
    } else if (!temFreq) {
      sit = "PENDÊNCIA POR FALTA";
    } else if (freqPct < criterios.freqMinima && !temNota) {
      sit = "PENDÊNCIA POR NOTA E PRESENÇA";
    } else if (freqPct < criterios.freqMinima) {
      sit = "PENDÊNCIA POR FALTA";
    } else if (nota >= criterios.notaMinima) {
      sit = "APROVADO";
    } else {
      sit = "PENDÊNCIA POR NOTA";
    }

    registros.push({
      nomeExcel:   nomeRaw,
      saiu:        todosSaiu,
      presencas:   presencas,
      faltas:      faltas,
      totalTempos: totalTempos,
      freqPct:     freqPct,
      nota:        nota,
      notaObs:     notaObs,
      situacao:    sit,
      ano:         ano,
      disciplina:  nomeDisc
    });
  }

  return { disciplina: nomeDisc, ano: ano, registros: registros, extracaoFalhou: extracaoFalhou };
}


// =====================================================
// NÚCLEO: lê Excel e produz plano de importação
// Retorna { abas: [...], porAluno: {...}, novos: [...],
//           similares: [...], exatos: [...] }
// =====================================================
function gerarPlanoImportacao_() {
  var ss = abrirExcel_();
  if (!ss) return null;

  var cadastro     = lerCadastroAlunos_();        // cadastro REAL do sistema — nunca é alterado
  var cadastroDisc = lerCadastroDisciplinas_();   // idem, para disciplinas
  var abas         = ss.getSheets();

  var plano = {
    registros:      [],   // tudo que entra no Historico_Consolidado
    exatos:         [],   // casamentos exatos de aluno (nome idêntico)
    similares:      [],   // casamentos de aluno por similaridade (revisar)
    novos:          [],   // alunos não encontrados (cadastrar)
    ignorados:      [],   // linhas puladas (sem dado algum)
    discExatas:     [],   // disciplinas casadas exatamente
    discSimilares:  [],   // disciplinas casadas por similaridade (revisar)
    discNovas:      [],   // disciplinas do Excel sem correspondência no Cadastro_Disciplinas
    discManuais:    [],   // disciplinas casadas via MAPEAMENTO_MANUAL_DISCIPLINAS
    abasComErro:    [],   // abas onde o nome da disciplina não pôde ser extraído do cabeçalho
  };

  // Lista separada dos alunos novos já detectados NESTA importação.
  // É consultada com o mesmo critério de similaridade do cadastro real,
  // assim a 2ª, 3ª... ocorrência do mesmo aluno (com grafia ligeiramente
  // diferente entre abas) casa com o registro novo já criado, em vez de
  // gerar um segundo cadastro duplicado.
  var novosNestaImportacao = [];
  var proxMat = parseInt(proximaMatricula_(cadastro).replace("IBTR-", ""));

  abas.forEach(function(ws) {
    var nomeAba = ws.getName();
    if (ABAS_IGNORAR.some(function(x) { return x.trim() === nomeAba.trim(); })) return;

    var parsed = parsearAba_(ws, nomeAba);
    if (parsed.registros.length === 0) return;

    // Se a extração do nome da disciplina falhou (cabeçalho não reconhecido),
    // a aba inteira é pulada e reportada separadamente — nunca tenta casar
    // um nome de disciplina inválido, que sempre resultaria em "disciplina
    // nova" fantasma poluindo o Histórico.
    if (parsed.extracaoFalhou) {
      plano.abasComErro.push({ aba: nomeAba, registros: parsed.registros.length });
      return;
    }

    // --- Cruzamento de disciplina: uma vez por aba ---
    var nomeDiscExcel = parsed.disciplina;
    var casoDisc = casarDisciplina_(nomeDiscExcel, cadastroDisc);
    var disciplinaOficial;

    if (casoDisc.tipo === "exato" || casoDisc.tipo === "similar" || casoDisc.tipo === "manual") {
      disciplinaOficial = casoDisc.match.codigo + " — " + casoDisc.match.nome;
      var registroDisc = {
        excel:   nomeDiscExcel,
        sistema: casoDisc.match.codigo + " — " + casoDisc.match.nome,
        sim:     Math.round(casoDisc.sim * 100)
      };
      if (casoDisc.tipo === "exato")        plano.discExatas.push(registroDisc);
      else if (casoDisc.tipo === "manual")  plano.discManuais.push(registroDisc);
      else                                  plano.discSimilares.push(registroDisc);
    } else {
      // Disciplina não encontrada no Cadastro_Disciplinas.
      // Mantém o nome do Excel tal qual, mas reporta para revisão —
      // não cadastra disciplina nova automaticamente (diferente de aluno).
      disciplinaOficial = nomeDiscExcel;
      if (!plano.discNovas.some(function(d){ return normalizarNome_(d.excel) === normalizarNome_(nomeDiscExcel); })) {
        plano.discNovas.push({ excel: nomeDiscExcel, sim: Math.round(casoDisc.sim * 100) });
      }
    }

    parsed.registros.forEach(function(reg) {
      var caso = casarNome_(reg.nomeExcel, cadastro);

      var matricula, nomeSistema, tipoAluno;

      if (caso.tipo === "exato" || caso.tipo === "similar") {
        matricula   = caso.match.matricula;
        nomeSistema = caso.match.matricula + " — " + caso.match.nome;
        tipoAluno   = caso.tipo;

        if (caso.tipo === "exato") {
          plano.exatos.push({ excel: reg.nomeExcel, sistema: caso.match.nome, mat: matricula });
        } else {
          plano.similares.push({
            excel:   reg.nomeExcel,
            sistema: caso.match.nome,
            mat:     matricula,
            sim:     Math.round(caso.sim * 100)
          });
        }
      } else {
        // Não bateu com o cadastro real. Antes de criar um aluno novo,
        // verifica se já criamos um "novo" equivalente nesta mesma
        // importação (outra aba, grafia ligeiramente diferente).
        var casoNovo = casarNome_(reg.nomeExcel, novosNestaImportacao);

        if (casoNovo.tipo === "exato" || casoNovo.tipo === "similar") {
          matricula   = casoNovo.match.matricula;
          nomeSistema = casoNovo.match.matricula + " — " + casoNovo.match.nome;
          tipoAluno   = "novo";  // continua contabilizado como novo cadastro
        } else {
          var novaMatricula = "IBTR-" + String(proxMat).padStart(3, "0");
          proxMat++;
          var novoAluno = {
            matricula: novaMatricula,
            nome:      reg.nomeExcel,
            normNome:  normalizarNome_(reg.nomeExcel),
            situacao:  "Inativo"
          };
          novosNestaImportacao.push(novoAluno);
          plano.novos.push({ matricula: novaMatricula, nomeExcel: reg.nomeExcel, situacao: "Inativo" });

          matricula   = novaMatricula;
          nomeSistema = novaMatricula + " — " + reg.nomeExcel;
          tipoAluno   = "novo";
        }
      }

      // Monta linha do Historico_Consolidado
      // A=Ano B=Aluno C=Disciplina D=Avaliacao E=Media F=Presencas
      // G=Total_Tempos H=Frequencia% I=Situacao
      var freqStr = reg.totalTempos > 0 ? reg.freqPct + "%" : "0%";

      plano.registros.push({
        ano:         reg.ano,
        aluno:       nomeSistema,
        disciplina:  disciplinaOficial,
        avaliacao:   reg.nota,
        media:       reg.nota,
        presencas:   reg.presencas,
        totalTempos: reg.totalTempos,
        freqStr:     freqStr,
        situacao:    reg.situacao,
        notaObs:     reg.notaObs,
        tipoAluno:   tipoAluno,
        saiu:        reg.saiu,
        nomeOriginal:reg.nomeExcel,
        novaMatricula: tipoAluno === "novo" ? matricula : null
      });
    });
  });

  limparArquivoTemp_(ss);
  return plano;
}


// =====================================================
// MODO 1: PRÉVIA — gera relatório HTML sem gravar nada
// =====================================================
function previsualizarImportacao() {
  var ui = SpreadsheetApp.getUi();
  ui.alert("Aguarde", "Lendo o arquivo Excel... isso pode levar 20–40 segundos.", ui.ButtonSet.OK);

  var plano = gerarPlanoImportacao_();
  if (!plano) return;

  var total    = plano.registros.length;
  var nExatos  = plano.exatos.length;
  var nSim     = plano.similares.length;
  var nNovos   = plano.novos.length;

  // --- Seção de alunos similares (os mais importantes de revisar) ---
  var linhasSim = "";
  var vistosSim = {};
  plano.similares.forEach(function(s) {
    var chave = s.excel + "|" + s.mat;
    if (vistosSim[chave]) return;
    vistosSim[chave] = true;
    linhasSim +=
      '<tr><td>' + s.excel + '</td>' +
      '<td>' + s.sistema + '</td>' +
      '<td>' + s.mat + '</td>' +
      '<td style="text-align:center">' + s.sim + '%</td></tr>';
  });

  // --- Seção de alunos novos ---
  var linhasNovos = "";
  plano.novos.forEach(function(n) {
    linhasNovos +=
      '<tr><td>' + n.matricula + '</td>' +
      '<td>' + n.nomeExcel + '</td>' +
      '<td>Inativo</td></tr>';
  });

  // --- Resumo por disciplina ---
  var porDisc = {};
  plano.registros.forEach(function(r) {
    var k = r.ano + " — " + r.disciplina;
    if (!porDisc[k]) porDisc[k] = { total: 0, aprov: 0, pend: 0 };
    porDisc[k].total++;
    if (r.situacao === "APROVADO") porDisc[k].aprov++;
    else porDisc[k].pend++;
  });
  var linhasDisc = "";
  Object.keys(porDisc).sort().forEach(function(k) {
    var d = porDisc[k];
    linhasDisc +=
      '<tr><td>' + k + '</td>' +
      '<td style="text-align:center">' + d.total + '</td>' +
      '<td style="text-align:center;color:#1E5C0A">' + d.aprov + '</td>' +
      '<td style="text-align:center;color:#C5221F">' + d.pend + '</td></tr>';
  });

  // --- Seção de disciplinas por similaridade ---
  var linhasDiscSim = "";
  plano.discSimilares.forEach(function(d) {
    linhasDiscSim +=
      '<tr><td>' + d.excel + '</td>' +
      '<td>' + d.sistema + '</td>' +
      '<td style="text-align:center">' + d.sim + '%</td></tr>';
  });

  // --- Seção de disciplinas sem correspondência no sistema ---
  var linhasDiscNovas = "";
  plano.discNovas.forEach(function(d) {
    linhasDiscNovas +=
      '<tr><td>' + d.excel + '</td>' +
      '<td style="text-align:center;color:#B45309">' + d.sim + '%</td></tr>';
  });

  // --- Seção de disciplinas casadas via mapeamento manual ---
  var linhasDiscManual = "";
  plano.discManuais.forEach(function(d) {
    linhasDiscManual +=
      '<tr><td>' + d.excel + '</td>' +
      '<td>' + d.sistema + '</td></tr>';
  });

  // --- Seção de abas com erro de extração (nome de disciplina não identificado) ---
  var linhasAbasErro = "";
  plano.abasComErro.forEach(function(e) {
    linhasAbasErro +=
      '<tr><td>' + e.aba + '</td>' +
      '<td style="text-align:center">' + e.registros + '</td></tr>';
  });

  var html =
    '<!DOCTYPE html><html><head><meta charset="UTF-8"><style>' +
    'body{font-family:Arial;margin:0;padding:20px;font-size:12px;color:#202124}' +
    'h1{color:#B40000;font-size:16px}h2{color:#B40000;font-size:13px;margin-top:20px}' +
    '.cards{display:flex;gap:12px;flex-wrap:wrap;margin:12px 0}' +
    '.card{background:#f8f9fa;border:1px solid #e0e0e0;border-radius:8px;padding:12px 16px;min-width:120px}' +
    '.card .n{font-size:26px;font-weight:bold;color:#B40000}' +
    '.card .l{font-size:10px;color:#80868B;margin-top:2px}' +
    '.ok{color:#1E5C0A}.warn{color:#B45309}.new{color:#8B0000}.err{color:#C5221F}' +
    'table{width:100%;border-collapse:collapse;font-size:11px;margin-top:8px}' +
    'th{background:#B40000;color:#fff;padding:5px 6px;text-align:left}' +
    'td{padding:4px 6px;border-bottom:1px solid #f0f0f0}' +
    'tr:hover{background:#f8f9fa}' +
    '.aviso{background:#FFF8E1;border-left:4px solid #FFC107;padding:10px 14px;' +
    'border-radius:4px;margin:12px 0;font-size:11px}' +
    '.np{margin-top:20px}@media print{.np{display:none}}' +
    '</style></head><body>' +
    '<h1>📋 Prévia de Importação — IBTRADCA</h1>' +
    '<p style="color:#80868B">Esta é apenas uma PRÉVIA. Nada foi gravado ainda.</p>' +

    '<div class="cards">' +
    '<div class="card"><div class="n ok">' + total + '</div><div class="l">Registros no histórico</div></div>' +
    '<div class="card"><div class="n ok">' + nExatos + '</div><div class="l">Casamentos exatos</div></div>' +
    '<div class="card"><div class="n warn">' + (new Set(plano.similares.map(function(s){return s.excel;}))).size + '</div><div class="l">Casamentos por similaridade</div></div>' +
    '<div class="card"><div class="n new">' + nNovos + '</div><div class="l">Alunos novos a cadastrar</div></div>' +
    '<div class="card"><div class="n warn">' + plano.discSimilares.length + '</div><div class="l">Disciplinas por similaridade</div></div>' +
    '<div class="card"><div class="n err">' + plano.discNovas.length + '</div><div class="l">Disciplinas SEM código no sistema</div></div>' +
    '<div class="card"><div class="n err">' + plano.abasComErro.length + '</div><div class="l">Abas com nome não identificado</div></div>' +
    '</div>' +

    (linhasAbasErro ? (
      '<h2>❌ Abas onde a disciplina não pôde ser identificada</h2>' +
      '<div class="aviso" style="border-left-color:#C5221F;background:#FCE4D6">' +
      '<strong>Estas abas foram IGNORADAS por completo — nenhum registro delas entra na importação.</strong><br>' +
      'O cabeçalho da aba não seguiu nenhum padrão reconhecido pelo sistema, então o nome da disciplina não pôde ' +
      'ser extraído com segurança. Abra a aba no Excel, confira a linha 1, e avise para ajustarmos a extração ' +
      '— ou renomeie o cabeçalho para o padrão "FREQUENCIA DISCIPLINA : NOME ... PROFESSOR: FULANO".</div>' +
      '<table><thead><tr><th>Aba do Excel</th><th>Registros ignorados</th></tr></thead><tbody>' +
      linhasAbasErro + '</tbody></table>'
    ) : '') +

    (linhasDiscNovas ? (
      '<h2>🚫 Disciplinas sem correspondência no Cadastro_Disciplinas</h2>' +
      '<div class="aviso" style="border-left-color:#C5221F">Estas disciplinas do Excel não foram encontradas no sistema. ' +
      'Serão gravadas no Histórico com o nome do Excel, SEM código — o que gera duplicação visual com registros nativos. ' +
      'Recomendado: cadastre essas disciplinas em Cadastro_Disciplinas antes de executar, ou avise se algum nome precisa de ajuste manual.</div>' +
      '<table><thead><tr><th>Nome no Excel</th><th>Melhor similaridade encontrada</th></tr></thead><tbody>' +
      linhasDiscNovas + '</tbody></table>'
    ) : '<h2 class="ok">✅ Todas as disciplinas do Excel foram encontradas no Cadastro_Disciplinas</h2>') +

    (linhasDiscManual ? (
      '<h2 class="ok">🔗 Disciplinas casadas via mapeamento manual</h2>' +
      '<div class="aviso" style="border-left-color:#1E5C0A;background:#E2EFDA">Estes nomes não bateram por similaridade textual, ' +
      'mas foram resolvidos pela tabela de apelidos definida no script (MAPEAMENTO_MANUAL_DISCIPLINAS).</div>' +
      '<table><thead><tr><th>Nome no Excel</th><th>Disciplina no sistema (com código)</th></tr></thead><tbody>' +
      linhasDiscManual + '</tbody></table>'
    ) : '') +

    (linhasDiscSim ? (
      '<h2>⚠️ Disciplinas casadas por similaridade — REVISAR</h2>' +
      '<div class="aviso">Confirme que cada disciplina do Excel corresponde mesmo à disciplina do sistema indicada.</div>' +
      '<table><thead><tr><th>Nome no Excel</th><th>Disciplina no sistema (com código)</th><th>Similaridade</th></tr></thead><tbody>' +
      linhasDiscSim + '</tbody></table>'
    ) : '') +

    (linhasSim ? (
      '<h2>⚠️ Casamentos por similaridade — REVISAR</h2>' +
      '<div class="aviso">Estes nomes não bateram exatamente. Verifique se o aluno do Excel é o mesmo do sistema antes de executar.</div>' +
      '<table><thead><tr><th>Nome no Excel</th><th>Nome no sistema</th><th>Matrícula</th><th>Similaridade</th></tr></thead><tbody>' +
      linhasSim + '</tbody></table>'
    ) : '<h2 class="ok">✅ Nenhum casamento por similaridade — todos os nomes bateram exatamente</h2>') +

    (linhasNovos ? (
      '<h2>🆕 Alunos novos — serão cadastrados como Inativo</h2>' +
      '<table><thead><tr><th>Matrícula gerada</th><th>Nome (do Excel)</th><th>Situação</th></tr></thead><tbody>' +
      linhasNovos + '</tbody></table>'
    ) : '<h2 class="ok">✅ Nenhum aluno novo — todos já estão no cadastro</h2>') +

    '<h2>📚 Resumo por disciplina</h2>' +
    '<table><thead><tr><th>Ano — Disciplina</th><th>Total</th><th>Aprovados</th><th>Pendências</th></tr></thead><tbody>' +
    linhasDisc + '</tbody></table>' +

    '<div class="aviso" style="margin-top:20px"><strong>Próximo passo:</strong> se a prévia estiver correta, ' +
    'feche esta janela e execute <strong>executarImportacao()</strong> no Apps Script.</div>' +

    '<div class="np"><button id="btn-imprimir" onclick="imprimirComSeguranca()" ' +
    'style="padding:9px 20px;background:#B40000;color:#fff;border:none;border-radius:6px;cursor:pointer;font-size:12px">' +
    '🖨 Imprimir / Salvar PDF</button></div>' +
    '<script>' +
    'function imprimirComSeguranca(){' +
      'var btn=document.getElementById("btn-imprimir");' +
      'btn.disabled=true;btn.textContent="Preparando...";' +
      'requestAnimationFrame(function(){' +
        'requestAnimationFrame(function(){' +
          'setTimeout(function(){' +
            'window.print();' +
            'btn.disabled=false;btn.textContent="🖨 Imprimir / Salvar PDF";' +
          '},150);' +
        '});' +
      '});' +
    '}' +
    '</script>' +
    '</body></html>';

  SpreadsheetApp.getUi().showModalDialog(
    HtmlService.createHtmlOutput(html).setWidth(860).setHeight(620),
    "Prévia de Importação"
  );
}


// =====================================================
// MODO 2: EXECUTAR — grava de fato no sistema
// =====================================================
function executarImportacao() {
  var ui = SpreadsheetApp.getUi();

  var conf = ui.alert(
    "Confirmar importação",
    "Isso irá:\n\n" +
    "✔ Cadastrar alunos novos em Cadastro_Alunos (como Inativo)\n" +
    "✔ Gravar registros em Historico_Consolidado\n\n" +
    "Registros já existentes para o mesmo aluno+disciplina+ano\n" +
    "serão SUBSTITUÍDOS.\n\n" +
    "Você já executou a PRÉVIA e revisou os casamentos?\n\nConfirmar?",
    ui.ButtonSet.YES_NO
  );
  if (conf !== ui.Button.YES) return;

  ui.alert("Aguarde", "Processando... isso pode levar 30–60 segundos.", ui.ButtonSet.OK);

  var plano = gerarPlanoImportacao_();
  if (!plano) return;

  var planilha   = SpreadsheetApp.getActiveSpreadsheet();
  var abaAlunos  = planilha.getSheetByName("Cadastro_Alunos");
  var abaHist    = planilha.getSheetByName("Historico_Consolidado");

  // 1) Cadastrar alunos novos
  var novosGravados = 0;
  plano.novos.forEach(function(n) {
    abaAlunos.appendRow([n.matricula, n.nomeExcel.toUpperCase(), "Curso Básico", "Inativo"]);
    novosGravados++;
  });

  // 2) Remover entradas duplicadas no Histórico (mesmo ano+aluno+disciplina)
  var dadosHist = abaHist.getDataRange().getValues();
  // Monta set de chaves que serão importadas
  var chavesNovas = {};
  plano.registros.forEach(function(r) {
    var mat = r.aluno.split(" — ")[0].trim();
    chavesNovas[r.ano + "|" + mat + "|" + normalizar_(r.disciplina)] = true;
  });
  // Remove de baixo para cima
  for (var k = dadosHist.length - 1; k >= 1; k--) {
    var matH = extrairMatricula_(String(dadosHist[k][1] || ""));
    var chH  = String(dadosHist[k][0]) + "|" + matH + "|" + normalizar_(String(dadosHist[k][2] || ""));
    if (chavesNovas[chH]) abaHist.deleteRow(k + 1);
  }

  // 3) Gravar registros no Histórico
  var linhas = plano.registros.map(function(r) {
    return [
      r.ano, r.aluno, r.disciplina,
      r.avaliacao, r.media,
      r.presencas, r.totalTempos,
      r.freqStr, r.situacao
    ];
  });

  if (linhas.length > 0) {
    var ult = abaHist.getLastRow();
    abaHist.getRange(ult + 1, 1, linhas.length, 9).setValues(linhas);

    // Força coluna H (% Frequência) como texto puro — evita que o Sheets
    // reinterprete "100.0%" como o número decimal 1 (formato percentual nativo)
    abaHist.getRange(ult + 1, 8, linhas.length, 1).setNumberFormat("@");

    // Cores na coluna I (Situacao)
    for (var r = 0; r < linhas.length; r++) {
      var cor = "#FFFFFF";
      var s   = linhas[r][8];
      if (s === "APROVADO")                       cor = "#E2EFDA";
      if (s === "PENDÊNCIA POR NOTA")             cor = "#FFF2CC";
      if (s === "PENDÊNCIA POR FALTA")            cor = "#FCE4D6";
      if (s === "PENDÊNCIA POR NOTA E PRESENÇA")  cor = "#FCE4D6";
      abaHist.getRange(ult + 1 + r, 9).setBackground(cor);
    }
  }

  // Cabeçalho se não existe
  var cab = abaHist.getRange(1, 1, 1, 9).getValues()[0];
  if (!cab[0] || String(cab[0]).trim() === "") {
    abaHist.getRange(1, 1, 1, 9).setValues([[
      "Ano","Aluno","Disciplina","Avaliacao","Media",
      "Presencas","Total_Tempos","% Frequência","Situacao"
    ]]);
    abaHist.getRange(1,1,1,9)
      .setBackground("#B40000").setFontColor("#FFFFFF").setFontWeight("bold");
  }

  abaHist.autoResizeColumns(1, 9);

  ui.alert(
    "Importação concluída!",
    "✔ " + novosGravados + " aluno(s) novo(s) cadastrado(s)\n" +
    "✔ " + linhas.length + " registro(s) gravado(s) no Histórico\n\n" +
    "Verifique a aba Historico_Consolidado.",
    ui.ButtonSet.OK
  );
}


// =====================================================
// LIMPEZA DE REDUNDÂNCIAS NO HISTÓRICO
//
// Corrige resquícios de importações anteriores onde a mesma
// disciplina ficou gravada duas vezes para o mesmo aluno+ano:
// uma vez com código oficial ("IBTR-D20 — Geografia Bíblica")
// e outra vez sem código (texto cru do Excel, "GEOGRAFIA BIBLICA").
//
// Estratégia: agrupa por aluno (matrícula) + ano + nome de disciplina
// SEM código (normalizado). Quando o grupo tem mais de uma linha:
//   - Mantém a linha com código oficial, se existir uma.
//   - Se nenhuma linha do grupo tem código, tenta casar o nome puro
//     contra Cadastro_Disciplinas agora e adiciona o código.
//   - Soma presenças/faltas das linhas mescladas (evita perder dados
//     de frequência que estavam espalhados entre as duplicatas).
//   - Remove as linhas excedentes do grupo.
//
// Roda em modo de PRÉVIA por padrão (mostra o que seria feito).
// Para executar de fato, chame limparRedundanciasHistorico(true).
// =====================================================
function limparRedundanciasHistorico(executar) {
  executar = executar === true;
  var ui       = SpreadsheetApp.getUi();
  var planilha = SpreadsheetApp.getActiveSpreadsheet();
  var abaHist  = planilha.getSheetByName("Historico_Consolidado");

  var dados = abaHist.getDataRange().getValues();
  if (dados.length < 2) {
    ui.alert("Histórico vazio. Nada para limpar.");
    return;
  }

  var cadastroDisc = lerCadastroDisciplinas_();

  // Extrai nome puro da disciplina:
  //  - remove "IBTR-DNN — " se existir (registros já com código)
  //  - remove ": NOME_PROFESSOR" colado no final (resquício de
  //    importações antigas, antes da extração de cabeçalho ser corrigida)
  function nomePuroDisc_(texto) {
    var s = String(texto || "").trim();

    var m = s.match(/^IBTR-D\d+\s*—\s*(.+)$/i);
    if (m) s = m[1].trim();

    // Corta a partir de "PROFESSOR" se existir
    var idxProf = s.toUpperCase().indexOf("PROFESSOR");
    if (idxProf > -1) s = s.slice(0, idxProf);

    // Corta a partir de um ":" remanescente (separador "Nome : Professor")
    var idxDoisPontos = s.indexOf(":");
    if (idxDoisPontos > -1) s = s.slice(0, idxDoisPontos);

    return s.replace(/\s+/g, " ").trim();
  }

  // Agrupa linhas (índice no array `dados`, 0-based, pulando cabeçalho)
  // A chave usa o CÓDIGO OFICIAL da disciplina (resolvido via
  // casarDisciplina_, que já consulta o mapeamento manual) sempre que
  // possível — assim "Teologia Sistemática III" e "Sistemátia III"
  // caem no mesmo grupo mesmo sem nenhuma das duas ter código ainda.
  // Quando não há correspondência alguma, cai no nome normalizado puro.
  var grupos = {};  // chave → [ {idx, linha} ]
  for (var i = 1; i < dados.length; i++) {
    var linha = dados[i];
    if (!linha[1]) continue;

    var ano      = String(linha[0]);
    var mat      = extrairMatricula_(String(linha[1]));
    var nomePuro = nomePuroDisc_(linha[2]);

    var chaveDisc;
    var casoChave = casarDisciplina_(nomePuro, cadastroDisc);
    if (casoChave.tipo === "exato" || casoChave.tipo === "similar" || casoChave.tipo === "manual") {
      chaveDisc = casoChave.match.codigo;          // agrupa pelo código oficial
    } else {
      chaveDisc = normalizarNome_(nomePuro);        // fallback: nome puro normalizado
    }

    var chave = ano + "|" + mat + "|" + chaveDisc;
    if (!grupos[chave]) grupos[chave] = [];
    grupos[chave].push({ idx: i, linha: linha });
  }

  // Identifica grupos com redundância (mais de 1 linha)
  var planLimpeza = [];  // { chave, manter: linha_mesclada, remover: [idx,...] }

  Object.keys(grupos).forEach(function(chave) {
    var grupo = grupos[chave];
    if (grupo.length < 2) return;  // sem redundância

    // Linha com código oficial (se houver)
    var comCodigo = grupo.find(function(g) { return /^IBTR-D\d+/.test(String(g.linha[2])); });

    var base = comCodigo ? comCodigo.linha.slice() : grupo[0].linha.slice();

    // Se nenhuma linha do grupo tinha código ainda, resolve agora
    // (cobre o caso de duas grafias diferentes, nenhuma com código,
    // que só se agruparam por terem casado no mesmo código via mapeamento)
    if (!comCodigo) {
      var nomePuroBase = nomePuroDisc_(base[2]);
      var caso = casarDisciplina_(nomePuroBase, cadastroDisc);
      if (caso.tipo === "exato" || caso.tipo === "similar" || caso.tipo === "manual") {
        base[2] = caso.match.codigo + " — " + caso.match.nome;
      }
    }

    // Mescla presenças/faltas: usa o maior valor de Presencas e Total_Tempos
    // entre as linhas do grupo (evita perder dados de frequência reais).
    // A string de frequência é sempre RECONSTRUÍDA a partir dos números,
    // nunca copiada da célula bruta — o Google Sheets às vezes autoconverte
    // "100.0%" para o número decimal 1, e copiar o valor cru propagaria isso.
    var maxPresencas = 0, maxTotal = 0, melhorSit = base[8];
    grupo.forEach(function(g) {
      var p = Number(g.linha[5]) || 0;
      var t = Number(g.linha[6]) || 0;
      if (t > maxTotal) {
        maxTotal     = t;
        maxPresencas = p;
        melhorSit    = g.linha[8];
      }
    });
    var freqNumReal = maxTotal > 0
      ? parseFloat((maxPresencas / maxTotal * 100).toFixed(1))
      : 0;
    var melhorFreqStr = freqNumReal + "%";

    // Se a melhor nota (avaliação/média) está em outra linha do grupo, prioriza nota > 0
    var melhorNota = Number(base[3]) || 0;
    grupo.forEach(function(g) {
      var n = Number(g.linha[3]) || 0;
      if (n > melhorNota) melhorNota = n;
    });

    base[3] = melhorNota;
    base[4] = melhorNota;
    base[5] = maxPresencas;
    base[6] = maxTotal;
    base[7] = melhorFreqStr;
    base[8] = melhorSit;

    var idxManter = comCodigo ? comCodigo.idx : grupo[0].idx;
    var idxRemover = grupo
      .filter(function(g) { return g.idx !== idxManter; })
      .map(function(g) { return g.idx; });

    planLimpeza.push({
      chave:        chave,
      idxManter:    idxManter,
      linhaFinal:   base,
      idxRemover:   idxRemover,
      nomesOriginais: grupo.map(function(g) { return g.linha[2]; })
    });
  });

  if (planLimpeza.length === 0) {
    ui.alert("Nenhuma redundância encontrada!", "O Histórico já está limpo.", ui.ButtonSet.OK);
    return;
  }

  if (!executar) {
    // Modo prévia: gera relatório
    var linhasHtml = "";
    planLimpeza.forEach(function(p) {
      linhasHtml +=
        '<tr><td>' + p.linhaFinal[1] + '</td>' +
        '<td>' + p.nomesOriginais.join(' <br> + ') + '</td>' +
        '<td>' + p.linhaFinal[2] + '</td>' +
        '<td style="text-align:center">' + p.idxRemover.length + '</td></tr>';
    });

    var html =
      '<!DOCTYPE html><html><head><meta charset="UTF-8"><style>' +
      'body{font-family:Arial;margin:0;padding:20px;font-size:12px;color:#202124}' +
      'h1{color:#B40000;font-size:16px}' +
      'table{width:100%;border-collapse:collapse;font-size:11px;margin-top:8px}' +
      'th{background:#B40000;color:#fff;padding:5px 6px;text-align:left}' +
      'td{padding:5px 6px;border-bottom:1px solid #f0f0f0;vertical-align:top}' +
      '.aviso{background:#FFF8E1;border-left:4px solid #FFC107;padding:10px 14px;border-radius:4px;margin:12px 0}' +
      '</style></head><body>' +
      '<h1>🧹 Prévia de Limpeza — Redundâncias no Histórico</h1>' +
      '<div class="aviso"><strong>' + planLimpeza.length + ' grupo(s) duplicado(s) encontrado(s).</strong><br>' +
      'Nada foi alterado ainda. Para executar de fato, rode <code>limparRedundanciasHistorico(true)</code>.</div>' +
      '<table><thead><tr><th>Aluno</th><th>Disciplinas encontradas (mescladas)</th>' +
      '<th>Ficará registrado como</th><th>Linhas removidas</th></tr></thead><tbody>' +
      linhasHtml + '</tbody></table>' +
      '</body></html>';

    SpreadsheetApp.getUi().showModalDialog(
      HtmlService.createHtmlOutput(html).setWidth(820).setHeight(560),
      "Prévia de Limpeza"
    );
    return;
  }

  // Modo execução: aplica de fato
  var conf = ui.alert(
    "Confirmar limpeza",
    "Foram encontrados " + planLimpeza.length + " grupo(s) de disciplinas duplicadas.\n\n" +
    "Isso irá mesclar e remover linhas redundantes do Historico_Consolidado.\n" +
    "Esta ação não pode ser desfeita.\n\nConfirmar?",
    ui.ButtonSet.YES_NO
  );
  if (conf !== ui.Button.YES) return;

  // Atualiza linha mantida + coleta índices a remover
  var todosRemover = [];
  planLimpeza.forEach(function(p) {
    abaHist.getRange(p.idxManter + 1, 1, 1, 9).setValues([p.linhaFinal]);
    abaHist.getRange(p.idxManter + 1, 8, 1, 1).setNumberFormat("@");
    todosRemover = todosRemover.concat(p.idxRemover);
  });

  // Remove linhas excedentes de baixo para cima
  todosRemover.sort(function(a, b) { return b - a; });
  todosRemover.forEach(function(idx) {
    abaHist.deleteRow(idx + 1);
  });

  // Recolore a coluna Situacao de todo o histórico
  var dadosFinal = abaHist.getDataRange().getValues();
  for (var r = 1; r < dadosFinal.length; r++) {
    var s = String(dadosFinal[r][8]);
    var cor = "#FFFFFF";
    if (s === "APROVADO")                       cor = "#E2EFDA";
    if (s === "PENDÊNCIA POR NOTA")             cor = "#FFF2CC";
    if (s === "PENDÊNCIA POR FALTA")            cor = "#FCE4D6";
    if (s === "PENDÊNCIA POR NOTA E PRESENÇA")  cor = "#FCE4D6";
    abaHist.getRange(r + 1, 9).setBackground(cor);
  }

  ui.alert(
    "Limpeza concluída!",
    "✔ " + planLimpeza.length + " grupo(s) mesclado(s)\n" +
    "✔ " + todosRemover.length + " linha(s) redundante(s) removida(s)",
    ui.ButtonSet.OK
  );
}

function _limparRedundanciasHistoricoPrevia()  { limparRedundanciasHistorico(false); return "ok"; }
function _limparRedundanciasHistoricoExecutar(){ limparRedundanciasHistorico(true);  return "ok"; }


// =====================================================
// CORRIGIR FORMATO DA COLUNA % FREQUÊNCIA (correção retroativa)
//
// Conserta linhas já gravadas no Historico_Consolidado onde a coluna H
// virou um número decimal puro (ex: 1, 0.667) em vez do texto "100%",
// "66.7%" — isso acontecia quando o Google Sheets autoconvertia a
// string de porcentagem para seu formato numérico nativo.
//
// Reconstrói o valor sempre a partir de Presencas/Total_Tempos
// (colunas F e G), que são números confiáveis, e regrava a coluna H
// como texto puro.
// =====================================================
function corrigirFormatoFrequenciaHistorico() {
  var ui       = SpreadsheetApp.getUi();
  var planilha = SpreadsheetApp.getActiveSpreadsheet();
  var abaHist  = planilha.getSheetByName("Historico_Consolidado");

  var dados = abaHist.getDataRange().getValues();
  if (dados.length < 2) {
    ui.alert("Histórico vazio. Nada para corrigir.");
    return;
  }

  var corrigidas = 0;
  var novaColH   = [];

  for (var i = 1; i < dados.length; i++) {
    var linha   = dados[i];
    var valorH  = linha[7];
    var presencas = Number(linha[5]) || 0;
    var total     = Number(linha[6]) || 0;

    var freqCorreta = total > 0
      ? parseFloat((presencas / total * 100).toFixed(1))
      : 0;
    var strCorreta = freqCorreta + "%";

    // Detecta se o valor atual já é uma string de porcentagem válida
    var jaCorreto = (typeof valorH === "string" && valorH.indexOf("%") > -1);

    if (!jaCorreto) {
      corrigidas++;
    }
    novaColH.push([strCorreta]);
  }

  if (corrigidas === 0) {
    ui.alert("Tudo certo!", "Nenhuma célula com formato incorreto foi encontrada.", ui.ButtonSet.OK);
    return;
  }

  var conf = ui.alert(
    "Corrigir formato de % Frequência",
    "Foram encontradas " + corrigidas + " linha(s) com a coluna % Frequência em formato " +
    "numérico incorreto (ex: \"1\" em vez de \"100%\").\n\n" +
    "Isso irá recalcular e regravar a coluna H para todas as linhas do Histórico, " +
    "usando sempre Presenças ÷ Total de Tempos.\n\nConfirmar?",
    ui.ButtonSet.YES_NO
  );
  if (conf !== ui.Button.YES) return;

  abaHist.getRange(2, 8, novaColH.length, 1).setValues(novaColH);
  abaHist.getRange(2, 8, novaColH.length, 1).setNumberFormat("@");

  // Renomeia o cabeçalho da coluna H, se ainda estiver com o nome antigo
  var cabAtual = abaHist.getRange(1, 8).getValue();
  if (String(cabAtual).trim() !== "% Frequência") {
    abaHist.getRange(1, 8).setValue("% Frequência");
  }

  ui.alert(
    "Correção concluída!",
    "✔ " + corrigidas + " linha(s) corrigida(s)\n" +
    "✔ Coluna H formatada como texto puro\n" +
    "✔ Cabeçalho atualizado para \"% Frequência\"",
    ui.ButtonSet.OK
  );
}

function _corrigirFormatoFrequenciaHistorico() { corrigirFormatoFrequenciaHistorico(); return "ok"; }


// =====================================================
// RECALCULAR SITUAÇÃO DO HISTÓRICO (correção retroativa)
//
// O Historico_Consolidado é uma tabela ESTÁTICA: a coluna Situacao é
// calculada no momento em que cada linha é gravada (arquivamento ou
// importação) e nunca muda sozinha depois. Se os critérios acadêmicos
// (C2/C5 em Configuracoes) forem alterados DEPOIS que linhas já
// existiam, essas linhas antigas continuam com a situação calculada
// pelo critério antigo — parecendo "errado" mesmo o sistema estando
// correto.
//
// Esta função varre todo o Histórico e RECALCULA a coluna I (Situacao)
// de cada linha usando os critérios ATUAIS de Configuracoes. Não toca
// em Ano, Aluno, Disciplina, Avaliacao, Media, Presencas, Total_Tempos
// nem % Frequência — só a situação derivada desses números.
// =====================================================
function recalcularSituacaoHistorico() {
  var ui       = SpreadsheetApp.getUi();
  var planilha = SpreadsheetApp.getActiveSpreadsheet();
  var abaHist  = planilha.getSheetByName("Historico_Consolidado");

  var dados = abaHist.getDataRange().getValues();
  if (dados.length < 2) {
    ui.alert("Histórico vazio. Nada para recalcular.");
    return;
  }

  var criterios = obterCriteriosAcademicos_();

  var mudancas = [];  // { idx, de, para }
  var novaColI = [];

  for (var i = 1; i < dados.length; i++) {
    var linha = dados[i];
    if (!linha[1]) { novaColI.push([linha[8]]); continue; }

    var media   = Number(linha[3]) || 0;   // D = Avaliacao
    var freqStr = String(linha[7] || "0%"); // H = % Frequência
    var freqNum = parseFloat(freqStr.replace("%", "").replace(",", ".")) || 0;
    var total   = Number(linha[6]) || 0;    // G = Total_Tempos

    var temNota = media > 0;
    var temFreq = total > 0;

    var sitNova;
    if (!temFreq && !temNota) {
      sitNova = "PENDÊNCIA POR NOTA E PRESENÇA";
    } else if (!temFreq) {
      sitNova = "PENDÊNCIA POR FALTA";
    } else if (freqNum < criterios.freqMinima && !temNota) {
      sitNova = "PENDÊNCIA POR NOTA E PRESENÇA";
    } else if (freqNum < criterios.freqMinima) {
      sitNova = "PENDÊNCIA POR FALTA";
    } else if (media >= criterios.notaMinima) {
      sitNova = "APROVADO";
    } else {
      sitNova = "PENDÊNCIA POR NOTA";
    }

    var sitAntiga = String(linha[8] || "");
    if (sitNova !== sitAntiga) {
      mudancas.push({ idx: i, de: sitAntiga, para: sitNova, aluno: linha[1], disc: linha[2] });
    }
    novaColI.push([sitNova]);
  }

  if (mudancas.length === 0) {
    ui.alert("Tudo certo!", "Nenhuma linha precisava de recálculo — o Histórico já reflete os critérios atuais (nota mínima " + criterios.notaMinima + ", frequência mínima " + criterios.freqMinima + "%).", ui.ButtonSet.OK);
    return;
  }

  var amostra = mudancas.slice(0, 8).map(function(m) {
    return "• " + m.aluno + " — " + m.disc + "\n   " + m.de + " → " + m.para;
  }).join("\n\n");
  var resto = mudancas.length > 8 ? "\n\n... e mais " + (mudancas.length - 8) + " linha(s)." : "";

  var conf = ui.alert(
    "Recalcular situação do Histórico",
    "Critérios atuais: nota mínima " + criterios.notaMinima + ", frequência mínima " + criterios.freqMinima + "%.\n\n" +
    mudancas.length + " linha(s) têm situação desatualizada:\n\n" + amostra + resto +
    "\n\nIsso atualiza SÓ a coluna Situação — nota, presença e frequência não são alteradas." +
    "\n\nConfirmar?",
    ui.ButtonSet.YES_NO
  );
  if (conf !== ui.Button.YES) return;

  abaHist.getRange(2, 9, novaColI.length, 1).setValues(novaColI);

  // Recolore a coluna I inteira
  var dadosFinal = abaHist.getDataRange().getValues();
  for (var r = 1; r < dadosFinal.length; r++) {
    var s = String(dadosFinal[r][8]);
    var cor = "#FFFFFF";
    if (s === "APROVADO")                       cor = "#E2EFDA";
    if (s === "PENDÊNCIA POR NOTA")             cor = "#FFF2CC";
    if (s === "PENDÊNCIA POR FALTA")            cor = "#FCE4D6";
    if (s === "PENDÊNCIA POR NOTA E PRESENÇA")  cor = "#FCE4D6";
    abaHist.getRange(r + 1, 9).setBackground(cor);
  }

  ui.alert("Recálculo concluído!", "✔ " + mudancas.length + " linha(s) atualizada(s) com os novos critérios.", ui.ButtonSet.OK);
}

function _recalcularSituacaoHistorico() { recalcularSituacaoHistorico(); return "ok"; }


// =====================================================
// REMOVER LINHAS "FANTASMA" DO HISTÓRICO
//
// Remove registros onde NADA aconteceu: nota = 0, presenças = 0,
// total de tempos = 0. Esse padrão aparece quando uma importação
// trouxe um aluno listado numa disciplina que ainda não tinha
// começado (sem nenhuma aula registrada no Excel).
//
// Por que isso importa: arquivarDisciplina() preserva qualquer
// registro já existente para aluno+disciplina+ano. Se essas linhas
// fantasma ficarem no Histórico, quando a disciplina realmente for
// ministrada e arquivada, o aluno será PULADO (por já "ter registro")
// e nunca receberá o resultado real.
//
// Roda em modo PRÉVIA por padrão. Para executar de fato, chame
// removerLinhasFantasmaHistorico(true).
// =====================================================
function removerLinhasFantasmaHistorico(executar) {
  executar = executar === true;
  var ui       = SpreadsheetApp.getUi();
  var planilha = SpreadsheetApp.getActiveSpreadsheet();
  var abaHist  = planilha.getSheetByName("Historico_Consolidado");

  var dados = abaHist.getDataRange().getValues();
  if (dados.length < 2) {
    ui.alert("Histórico vazio. Nada para verificar.");
    return;
  }

  var fantasmas = [];  // { idx, linha }
  for (var i = 1; i < dados.length; i++) {
    var linha = dados[i];
    if (!linha[1]) continue;

    var nota      = Number(linha[3]) || 0;
    var presencas = Number(linha[5]) || 0;
    var total     = Number(linha[6]) || 0;

    if (nota === 0 && presencas === 0 && total === 0) {
      fantasmas.push({ idx: i, linha: linha });
    }
  }

  if (fantasmas.length === 0) {
    ui.alert("Nenhuma linha fantasma encontrada!", "O Histórico está limpo.", ui.ButtonSet.OK);
    return;
  }

  if (!executar) {
    var linhasHtml = "";
    fantasmas.forEach(function(f) {
      linhasHtml +=
        '<tr><td>' + f.linha[0] + '</td><td>' + f.linha[1] + '</td>' +
        '<td>' + f.linha[2] + '</td><td>' + f.linha[8] + '</td></tr>';
    });

    var html =
      '<!DOCTYPE html><html><head><meta charset="UTF-8"><style>' +
      'body{font-family:Arial;margin:0;padding:20px;font-size:12px;color:#202124}' +
      'h1{color:#B40000;font-size:16px}' +
      'table{width:100%;border-collapse:collapse;font-size:11px;margin-top:8px}' +
      'th{background:#B40000;color:#fff;padding:5px 6px;text-align:left}' +
      'td{padding:5px 6px;border-bottom:1px solid #f0f0f0}' +
      '.aviso{background:#FFF8E1;border-left:4px solid #FFC107;padding:10px 14px;border-radius:4px;margin:12px 0}' +
      '</style></head><body>' +
      '<h1>👻 Prévia — Linhas Fantasma no Histórico</h1>' +
      '<div class="aviso"><strong>' + fantasmas.length + ' linha(s) sem nenhum dado real encontrada(s)</strong> ' +
      '(nota 0, presenças 0, total de tempos 0).<br>' +
      'São disciplinas que ainda não tinham começado quando o Excel foi importado. ' +
      'Recomenda-se remover para não bloquear o arquivamento real no futuro.<br><br>' +
      'Nada foi alterado ainda. Para executar, rode <code>removerLinhasFantasmaHistorico(true)</code>.</div>' +
      '<table><thead><tr><th>Ano</th><th>Aluno</th><th>Disciplina</th><th>Situação atual</th></tr></thead><tbody>' +
      linhasHtml + '</tbody></table>' +
      '</body></html>';

    SpreadsheetApp.getUi().showModalDialog(
      HtmlService.createHtmlOutput(html).setWidth(820).setHeight(560),
      "Prévia — Linhas Fantasma"
    );
    return;
  }

  var conf = ui.alert(
    "Confirmar remoção",
    "Foram encontradas " + fantasmas.length + " linha(s) fantasma (sem nenhum dado real).\n\n" +
    "Isso irá removê-las do Historico_Consolidado.\nEsta ação não pode ser desfeita.\n\nConfirmar?",
    ui.ButtonSet.YES_NO
  );
  if (conf !== ui.Button.YES) return;

  var indices = fantasmas.map(function(f) { return f.idx; });
  indices.sort(function(a, b) { return b - a; });  // remove de baixo para cima
  indices.forEach(function(idx) { abaHist.deleteRow(idx + 1); });

  ui.alert("Limpeza concluída!", "✔ " + fantasmas.length + " linha(s) fantasma removida(s).", ui.ButtonSet.OK);
}

function _removerLinhasFantasmaHistoricoPrevia()   { removerLinhasFantasmaHistorico(false); return "ok"; }
function _removerLinhasFantasmaHistoricoExecutar() { removerLinhasFantasmaHistorico(true);  return "ok"; }